const mongoose = require('mongoose');

const rankHolderSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    image: {
        type: String,
        required: true
    },
    category: {
        type: String,
        required: true
    },
    globalRank: {
        type: String,
        default: ""
    },
    indiaRank: {
        type: String,
        default: ""
    },
    course: {
        type: String,
        required: true
    },
    session: {
        type: String,
        required: true
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('RankHolder', rankHolderSchema);
