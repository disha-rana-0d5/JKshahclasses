const LandingPageContent = require('../models/LandingPageContent');

// @desc    Get landing page content
// @route   GET /api/content/landing
// @access  Public
exports.getLandingContent = async (req, res) => {
    try {
        let content = await LandingPageContent.findOne();

        // If no content exists, create a default one
        if (!content) {
            content = await LandingPageContent.create({});
        }

        res.status(200).json({
            success: true,
            data: content
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Server Error',
            error: error.message
        });
    }
};

// @desc    Update landing page content
// @route   PUT /api/content/landing
// @access  Private/Admin
exports.updateLandingContent = async (req, res) => {
    try {
        console.log("Received update request body:", JSON.stringify(req.body, null, 2));

        // Strip immutable fields from req.body to prevent conflicts
        const { _id, createdAt, updatedAt, __v, ...updateData } = req.body;

        console.log("Saving Online Experience Data:", JSON.stringify(updateData.onlineExperience, null, 2));

        const content = await LandingPageContent.findOneAndUpdate(
            {},
            { $set: updateData },
            { new: true, upsert: true, runValidators: true }
        );

        console.log("Content updated successfully. videoUrl in DB:", content?.onlineExperience?.videoUrl);

        console.log("Content updated successfully. New Header Badge:", content?.branchPage?.header?.badge);

        res.status(200).json({
            success: true,
            data: content
        });
    } catch (error) {
        console.error("Error updating landing content:", error);
        res.status(500).json({
            success: false,
            message: 'Server Error during update',
            error: error.message,
            stack: error.stack
        });
    }
};
