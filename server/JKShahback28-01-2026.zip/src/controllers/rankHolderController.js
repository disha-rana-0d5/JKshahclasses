const RankHolder = require('../models/RankHolder');

exports.getAllRankHolders = async (req, res) => {
    try {
        const rankHolders = await RankHolder.find().sort({ createdAt: -1 });
        res.status(200).json({
            success: true,
            data: rankHolders
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.addRankHolder = async (req, res) => {
    try {
        const rankHolder = await RankHolder.create(req.body);
        res.status(201).json({
            success: true,
            data: rankHolder
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
};

exports.updateRankHolder = async (req, res) => {
    try {
        const rankHolder = await RankHolder.findByIdAndUpdate(req.params.id, req.body, {
            new: true,
            runValidators: true
        });
        if (!rankHolder) {
            return res.status(404).json({
                success: false,
                message: 'Rank holder not found'
            });
        }
        res.status(200).json({
            success: true,
            data: rankHolder
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
};

exports.deleteRankHolder = async (req, res) => {
    try {
        const rankHolder = await RankHolder.findByIdAndDelete(req.params.id);
        if (!rankHolder) {
            return res.status(404).json({
                success: false,
                message: 'Rank holder not found'
            });
        }
        res.status(200).json({
            success: true,
            message: 'Rank holder deleted successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};
