const multer = require('multer');
const path = require('path');

// Set Storage Engine
const storage = multer.diskStorage({
    destination: './src/uploads/',
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

// Check File Type
function checkFileType(file, cb) {
    // Allowed ext
    const filetypes = /jpeg|jpg|png|gif|webp/;
    // Check ext
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    // Check mime
    const mimetype = filetypes.test(file.mimetype);

    if (mimetype && extname) {
        return cb(null, true);
    } else {
        cb('Error: Images Only!');
    }
}

// Init Upload
const upload = multer({
    storage: storage,
    limits: { fileSize: 5000000 }, // 5MB
    fileFilter: function (req, file, cb) {
        checkFileType(file, cb);
    }
}).single('image');


// Check Doc Type
function checkDocType(file, cb) {
    const filetypes = /pdf/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);

    if (mimetype && extname) {
        return cb(null, true);
    } else {
        cb('Error: PDFs Only!');
    }
}

// Init Doc Upload
const uploadDoc = multer({
    storage: storage,
    limits: { fileSize: 10000000 }, // 10MB
    fileFilter: function (req, file, cb) {
        checkDocType(file, cb);
    }
}).single('file');

exports.uploadImage = (req, res) => {
    console.log('Upload Image request received');
    upload(req, res, (err) => {
        if (err) {
            console.error('Multer error (image):', err);
            res.status(400).json({ message: err });
        } else {
            if (req.file == undefined) {
                console.error('No file in request (image)');
                res.status(400).json({ message: 'Error: No File Selected!' });
            } else {
                console.log('File uploaded successfully (image):', req.file.filename);
                const fileUrl = `/uploads/${req.file.filename}`;
                res.json({
                    message: 'File Uploaded!',
                    url: fileUrl
                });
            }
        }
    });
};

exports.uploadFile = (req, res) => {
    console.log('Upload File request received');
    uploadDoc(req, res, (err) => {
        if (err) {
            console.error('Multer error (file):', err);
            res.status(400).json({ message: err });
        } else {
            if (req.file == undefined) {
                console.error('No file in request (file)');
                res.status(400).json({ message: 'Error: No File Selected!' });
            } else {
                console.log('File uploaded successfully (file):', req.file.filename);
                const fileUrl = `/uploads/${req.file.filename}`;
                res.json({
                    message: 'File Uploaded!',
                    url: fileUrl
                });
            }
        }
    });
};

