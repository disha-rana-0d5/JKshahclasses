const Batch = require('../models/Batch');

// @desc    Get all batches
// @route   GET /api/batches
// @access  Public
exports.getBatches = async (req, res) => {
    try {
        const batches = await Batch.find();
        res.status(200).json({
            success: true,
            data: batches
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Server Error'
        });
    }
};

// @desc    Create new batch
// @route   POST /api/batches
// @access  Private/Admin
exports.createBatch = async (req, res) => {
    try {
        const batch = await Batch.create(req.body);
        res.status(201).json({
            success: true,
            data: batch
        });
    } catch (error) {
        if (error.name === 'ValidationError') {
            const messages = Object.values(error.errors).map(val => val.message);
            return res.status(400).json({
                success: false,
                error: messages
            });
        }
        res.status(500).json({
            success: false,
            error: 'Server Error'
        });
    }
};

// @desc    Delete batch
// @route   DELETE /api/batches/:id
// @access  Private/Admin
exports.deleteBatch = async (req, res) => {
    try {
        const batch = await Batch.findById(req.params.id);

        if (!batch) {
            return res.status(404).json({
                success: false,
                error: 'Batch not found'
            });
        }

        await batch.deleteOne();

        res.status(200).json({
            success: true,
            data: {}
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Server Error'
        });
    }
};
