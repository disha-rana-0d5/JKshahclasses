const CareerOpportunity = require('../models/CareerOpportunity');

exports.getAllCareerOpportunities = async (req, res) => {
    try {
        const opportunities = await CareerOpportunity.find().sort({ createdAt: -1 });
        res.status(200).json({
            success: true,
            data: opportunities
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.addOrUpdateCareerOpportunity = async (req, res) => {
    try {
        const { subCategory, image, opportunities } = req.body;
        const careerOpportunity = await CareerOpportunity.findOneAndUpdate(
            { subCategory },
            { image, opportunities },
            { upsert: true, new: true, runValidators: true }
        );
        res.status(200).json({
            success: true,
            data: careerOpportunity
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
};

exports.deleteCareerOpportunity = async (req, res) => {
    try {
        const careerOpportunity = await CareerOpportunity.findByIdAndDelete(req.params.id);
        if (!careerOpportunity) {
            return res.status(404).json({
                success: false,
                message: 'Career opportunity config not found'
            });
        }
        res.status(200).json({
            success: true,
            message: 'Career opportunity config deleted successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};
