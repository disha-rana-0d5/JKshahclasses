const express = require('express');
const router = express.Router();
const { getBatches, createBatch, deleteBatch } = require('../controllers/batchController');

router.route('/')
    .get(getBatches)
    .post(createBatch);

router.route('/:id')
    .delete(deleteBatch);

module.exports = router;
