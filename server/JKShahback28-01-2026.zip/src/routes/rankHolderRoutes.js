const express = require('express');
const router = express.Router();
const rankHolderController = require('../controllers/rankHolderController');

router.get('/', rankHolderController.getAllRankHolders);
router.post('/', rankHolderController.addRankHolder);
router.put('/:id', rankHolderController.updateRankHolder);
router.delete('/:id', rankHolderController.deleteRankHolder);

module.exports = router;
