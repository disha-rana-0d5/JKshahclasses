import React, { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { categoryApi, courseApi, levelApi, facultyApi, rankHolderApi, courseTimelineApi, careerOpportunityApi } from "../../api/api";

import { toast } from "sonner";

export interface Course {
    _id: string;
    slug: string;
    title: string;
    description: string;
    category: string;
    subCategory: string;
    price: number;
    originalPrice?: number;
    duration: string;
    lessons: number;
    rating: number;
    reviews: number;
    facultyName: string;
    facultyImage: string;
    discount?: string;
    highlights: string[];
    tags: string[];
    enrolledTotal: number;
    enrolledRecent: number;
    status: "Active" | "Draft" | "Archived";
    image: string;
    batchInfo?: string;
    level: string;
    // New fields
    syllabusModules?: {
        title: string;
        topics: any[];
        duration: string;
        pdfUrl?: string;
    }[];
    facultyDesignation?: string;
    facultySpecialization?: string;
    facultyExperience?: string;
    facultyStudents?: string;
    facultyRating?: number;
    facultyBio?: string;
    courseFeatures?: string[];
    whatYouLearn?: string[];
    whoShouldEnroll?: string[];
    reviewsList?: {
        name: string;
        rating: number;
        date: string;
        text: string;
        achievement: string;
        image: string;
    }[];
    videos?: {
        title: string;
        url: string;
        description?: string;
    }[];
    faqs?: {
        category: string;
        questions: {
            question: string;
            answer: string;
        }[];
    }[];
    testimonials?: {
        category: string;
        items: {
            name: string;
            message: string;
            image: string;
            designation: string;
            videoUrl: string;
        }[];
    }[];
    brochureUrl?: string;
    syllabusPdf?: string;
}

export interface Level {
    _id: string;
    name: string;
    description?: string;
}


export interface Category {
    _id: string;
    name: string;
    description?: string;
    parent?: string;
    whyTitle?: string;
    whyContent?: string;
    whyJKShahTitle?: string;
    whyJKShahContent?: string;
    slug?: string;
    metaTitle?: string;
    metaDescription?: string;
    metaKeywords?: string;
}

export interface Faculty {
    _id: string;
    name: string;
    designation: string;
    expertise: string;
    experience: number;
    rating: string;
    totalStudents: string;
    coursesTaught: string[];
    image: string;
    specialization: string;
    qualifications: string[];
    tagline: string;
    achievements: string[];
}

export interface RankHolder {
    _id: string;
    name: string;
    image: string;
    category: string;
    globalRank: string;
    indiaRank: string;
    course: string;
    session: string;
}

export interface CourseTimeline {
    _id: string;
    subCategory: string;
    image: string;
}

export interface CareerOpportunityConfig {
    _id: string;
    subCategory: string;
    image: string;
    opportunities: string[];
}

interface CourseContextType {
    courses: Course[];
    categories: Category[];
    levels: Level[];
    rankHolders: RankHolder[];
    addCourse: (course: Partial<Course>) => Promise<void>;
    updateCourse: (id: string, course: Partial<Course>) => Promise<void>;
    deleteCourse: (id: string) => Promise<void>;
    addCategory: (name: string, description?: string, parent?: string, slug?: string, metaTitle?: string, metaDescription?: string, metaKeywords?: string) => Promise<void>;
    updateCategory: (id: string, data: Partial<Category>) => Promise<void>;
    deleteCategory: (id: string, name: string) => Promise<void>;
    addLevel: (name: string) => Promise<void>;
    deleteLevel: (id: string, name: string) => Promise<void>;
    addRankHolder: (rankData: Partial<RankHolder>) => Promise<void>;
    updateRankHolder: (id: string, rankData: Partial<RankHolder>) => Promise<void>;
    deleteRankHolder: (id: string) => Promise<void>;
    courseTimelines: CourseTimeline[];
    addOrUpdateTimeline: (timelineData: Partial<CourseTimeline>) => Promise<void>;
    deleteTimeline: (id: string) => Promise<void>;
    careerConfigs: CareerOpportunityConfig[];
    addOrUpdateCareerConfig: (config: Partial<CareerOpportunityConfig>) => Promise<void>;
    deleteCareerConfig: (id: string) => Promise<void>;
    faculties: Faculty[];
    loading: boolean;
}


const CourseContext = createContext<CourseContextType | undefined>(undefined);

export function CourseProvider({ children }: { children: ReactNode }) {
    const [courses, setCourses] = useState<Course[]>([]);
    const [categories, setCategories] = useState<Category[]>([]);
    const [levels, setLevels] = useState<Level[]>([]);
    const [faculties, setFaculties] = useState<Faculty[]>([]);
    const [rankHolders, setRankHolders] = useState<RankHolder[]>([]);
    const [courseTimelines, setCourseTimelines] = useState<CourseTimeline[]>([]);
    const [careerConfigs, setCareerConfigs] = useState<CareerOpportunityConfig[]>([]);
    const [loading, setLoading] = useState(true);


    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const [catRes, courseRes, levelRes, facultyRes] = await Promise.all([
                    categoryApi.getCategories(),
                    courseApi.getCourses(),
                    levelApi.getLevels(),
                    facultyApi.getFaculties()
                ]);

                if (catRes.ok && catRes.data.success) {
                    setCategories(catRes.data.data);
                }
                if (courseRes.ok && courseRes.data.success) {
                    setCourses(courseRes.data.data);
                }
                if (levelRes.ok && levelRes.data.success) {
                    setLevels(levelRes.data.data);
                }
                if (facultyRes.ok && facultyRes.data.success) {
                    setFaculties(facultyRes.data.data);
                }

                // Fetch Rank Holders from API
                const rankRes = await rankHolderApi.getRankHolders();
                if (rankRes.ok && rankRes.data.success) {
                    setRankHolders(rankRes.data.data);
                }

                // Fetch Course Timelines from API
                const timelineRes = await courseTimelineApi.getTimelines();
                if (timelineRes.ok && timelineRes.data.success) {
                    setCourseTimelines(timelineRes.data.data);
                }

                // Fetch Career Opportunity Configs from API
                const careerRes = await careerOpportunityApi.getCareerOpportunities();
                if (careerRes.ok && careerRes.data.success) {
                    setCareerConfigs(careerRes.data.data);
                }

            } catch (error) {
                console.error("Failed to fetch data:", error);
                toast.error("Failed to load data from server");
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    const addCourse = async (courseData: Partial<Course>) => {
        try {
            const { ok, data } = await courseApi.addCourse(courseData);
            if (ok && data.success) {
                setCourses((prev) => [...prev, data.data]);
                toast.success("Course added successfully");
            } else {
                toast.error(data.message || "Failed to add course");
            }
        } catch (error) {
            toast.error("Failed to connect to server");
        }
    };

    const updateCourse = async (id: string, courseData: Partial<Course>) => {
        try {
            const { ok, data } = await courseApi.updateCourse(id, courseData);
            if (ok && data.success) {
                setCourses((prev) => prev.map(c => c._id === id ? data.data : c));
                toast.success("Course updated successfully");
            } else {
                toast.error(data.message || "Failed to update course");
            }
        } catch (error) {
            toast.error("Failed to connect to server");
        }
    };

    const deleteCourse = async (id: string) => {
        if (confirm("Are you sure you want to delete this course?")) {
            try {
                const { ok, data } = await courseApi.deleteCourse(id);
                if (ok && data.success) {
                    setCourses((prev) => prev.filter(c => c._id !== id));
                    toast.success("Course deleted successfully");
                } else {
                    toast.error(data.message || "Failed to delete course");
                }
            } catch (error) {
                toast.error("Failed to connect to server");
            }
        }
    };

    const addCategory = async (name: string, description?: string, parent?: string, slug?: string, metaTitle?: string, metaDescription?: string, metaKeywords?: string) => {
        if (!name.trim()) return;

        try {
            const { ok, data } = await categoryApi.addCategory(name.trim(), description, parent, slug, metaTitle, metaDescription, metaKeywords);
            if (ok && data.success) {
                setCategories((prev) => [...prev, data.data]);
                toast.success("Category added successfully");
            } else {
                toast.error(data.message || "Failed to add category");
            }
        } catch (error) {
            toast.error("Failed to connect to server");
        }
    };

    const updateCategory = async (id: string, categoryData: Partial<Category>) => {
        try {
            const { ok, data } = await categoryApi.updateCategory(id, categoryData);
            if (ok && data.success) {
                setCategories((prev) => prev.map(c => c._id === id ? data.data : c));
                toast.success("Category updated successfully");
            } else {
                toast.error(data.message || "Failed to update category");
            }
        } catch (error) {
            toast.error("Failed to connect to server");
        }
    };

    const deleteCategory = async (id: string, name: string) => {
        if (confirm(`Are you sure you want to delete category "${name}"?`)) {
            try {
                const { ok, data } = await categoryApi.deleteCategory(id);
                if (ok && data.success) {
                    setCategories((prev) => prev.filter((c) => c._id !== id));
                    setCourses(prev => prev.map(c => c.category === name ? { ...c, category: "Uncategorized" } : c));
                    toast.success("Category deleted successfully");
                } else {
                    toast.error(data.message || "Failed to delete category");
                }
            } catch (error) {
                toast.error("Failed to connect to server");
            }
        }
    };

    const addLevel = async (name: string) => {
        if (!name.trim()) return;

        try {
            const { ok, data } = await levelApi.addLevel(name.trim());
            if (ok && data.success) {
                setLevels((prev) => [...prev, data.data]);
                toast.success("Level added successfully");
            } else {
                toast.error(data.message || "Failed to add level");
            }
        } catch (error) {
            toast.error("Failed to connect to server");
        }
    };

    const deleteLevel = async (id: string, name: string) => {
        if (confirm(`Are you sure you want to delete level "${name}"?`)) {
            try {
                const { ok, data } = await levelApi.deleteLevel(id);
                if (ok && data.success) {
                    setLevels((prev) => prev.filter((l) => l._id !== id));
                    setCourses(prev => prev.map(c => c.level === name ? { ...c, level: "All" } : c));
                    toast.success("Level deleted successfully");
                } else {
                    toast.error(data.message || "Failed to delete level");
                }
            } catch (error) {
                toast.error("Failed to connect to server");
            }
        }
    };

    // Rank Holder Methods
    const addRankHolder = async (rankData: Partial<RankHolder>) => {
        try {
            const { ok, data } = await rankHolderApi.addRankHolder(rankData);
            if (ok && data.success) {
                setRankHolders((prev) => [...prev, data.data]);
                toast.success("Rank holder added successfully");
            } else {
                toast.error(data.message || "Failed to add rank holder");
            }
        } catch (error) {
            toast.error("Failed to connect to server");
        }
    };

    const updateRankHolder = async (id: string, rankData: Partial<RankHolder>) => {
        try {
            const { ok, data } = await rankHolderApi.updateRankHolder(id, rankData);
            if (ok && data.success) {
                setRankHolders((prev) => prev.map(r => r._id === id ? data.data : r));
                toast.success("Rank holder updated successfully");
            } else {
                toast.error(data.message || "Failed to update rank holder");
            }
        } catch (error) {
            toast.error("Failed to connect to server");
        }
    };

    const deleteRankHolder = async (id: string) => {
        if (confirm("Are you sure you want to delete this rank holder?")) {
            try {
                const { ok, data } = await rankHolderApi.deleteRankHolder(id);
                if (ok && data.success) {
                    setRankHolders((prev) => prev.filter(r => r._id !== id));
                    toast.success("Rank holder deleted successfully");
                } else {
                    toast.error(data.message || "Failed to delete rank holder");
                }
            } catch (error) {
                toast.error("Failed to connect to server");
            }
        }
    };

    // Course Timeline Methods
    const addOrUpdateTimeline = async (timelineData: Partial<CourseTimeline>) => {
        try {
            const { ok, data } = await courseTimelineApi.addOrUpdateTimeline(timelineData);
            if (ok && data.success) {
                const existingIndex = courseTimelines.findIndex(t => t.subCategory === data.data.subCategory);
                if (existingIndex > -1) {
                    setCourseTimelines(prev => prev.map(t => t.subCategory === data.data.subCategory ? data.data : t));
                } else {
                    setCourseTimelines(prev => [...prev, data.data]);
                }
                toast.success("Timeline saved successfully");
            } else {
                toast.error(data.message || "Failed to save timeline");
            }
        } catch (error) {
            toast.error("Failed to connect to server");
        }
    };

    const deleteTimeline = async (id: string) => {
        if (confirm("Are you sure you want to delete this course timeline?")) {
            try {
                const { ok, data } = await courseTimelineApi.deleteTimeline(id);
                if (ok && data.success) {
                    setCourseTimelines(prev => prev.filter(t => t._id !== id));
                    toast.success("Timeline deleted successfully");
                } else {
                    toast.error(data.message || "Failed to delete timeline");
                }
            } catch (error) {
                toast.error("Failed to connect to server");
            }
        }
    };

    // Career Opportunity Methods
    const addOrUpdateCareerConfig = async (configData: Partial<CareerOpportunityConfig>) => {
        try {
            const { ok, data } = await careerOpportunityApi.addOrUpdateCareerOpportunity(configData);
            if (ok && data.success) {
                const existingIndex = careerConfigs.findIndex(c => c.subCategory === data.data.subCategory);
                if (existingIndex > -1) {
                    setCareerConfigs(prev => prev.map(c => c.subCategory === data.data.subCategory ? data.data : c));
                } else {
                    setCareerConfigs(prev => [...prev, data.data]);
                }
                toast.success("Career config saved successfully");
            } else {
                toast.error(data.message || "Failed to save career config");
            }
        } catch (error) {
            toast.error("Failed to connect to server");
        }
    };

    const deleteCareerConfig = async (id: string) => {
        if (confirm("Are you sure you want to delete this career opportunity config?")) {
            try {
                const { ok, data } = await careerOpportunityApi.deleteCareerOpportunity(id);
                if (ok && data.success) {
                    setCareerConfigs(prev => prev.filter(c => c._id !== id));
                    toast.success("Config deleted successfully");
                } else {
                    toast.error(data.message || "Failed to delete config");
                }
            } catch (error) {
                toast.error("Failed to connect to server");
            }
        }
    };


    return (
        <CourseContext.Provider value={{
            courses, categories, levels, faculties, rankHolders,
            addCourse, updateCourse, deleteCourse,
            addCategory, updateCategory, deleteCategory,
            addLevel, deleteLevel,
            addRankHolder, updateRankHolder, deleteRankHolder,
            courseTimelines, addOrUpdateTimeline, deleteTimeline,
            careerConfigs, addOrUpdateCareerConfig, deleteCareerConfig,
            loading
        }}>

            {children}
        </CourseContext.Provider>
    );
}

export function useCourseContext() {
    const context = useContext(CourseContext);
    if (!context) {
        throw new Error("useCourseContext must be used within a CourseProvider");
    }
    return context;
}
