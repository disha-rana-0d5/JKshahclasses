import { useState, useEffect } from "react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { landingPageApi } from "../../api/api";
import { toast } from "sonner";
import { Loader2, Plus, Trash2, Save } from "lucide-react";
import { ImageUpload } from "../../components/ImageUpload";
import { FileUpload } from "../../components/FileUpload";

export function LandingPageManagement() {
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [content, setContent] = useState<any>(null);

    useEffect(() => {
        fetchContent();
    }, []);

    const fetchContent = async () => {
        try {
            setLoading(true);
            const { ok, data } = await landingPageApi.getLandingContent();
            if (ok && data.success) {
                const fetchedContent = data.data;
                // Initialize hero stats if missing/empty
                if (!fetchedContent.hero.stats || fetchedContent.hero.stats.length === 0) {
                    fetchedContent.hero.stats = [
                        { value: '98%', label: 'Success Rate' },
                        { value: '50K+', label: 'Students' },
                        { value: '450+', label: 'Rank Holders' }
                    ];
                }

                // Initialize quick info if missing/empty
                if (!fetchedContent.hero.quickInfo || fetchedContent.hero.quickInfo.length === 0) {
                    fetchedContent.hero.quickInfo = [
                        { label: 'Next Batch', value: 'Jan 15, 2024' },
                        { label: 'Limited Seats', value: '45 Left' }
                    ];
                }
                // Initialize whyChooseUs if missing/empty
                if (!fetchedContent.whyChooseUs?.statsGrid || fetchedContent.whyChooseUs.statsGrid.length === 0) {
                    fetchedContent.whyChooseUs = {
                        ...fetchedContent.whyChooseUs,
                        statsGrid: [
                            { value: "50,000+", label: "Students", color: "primary" },
                            { value: "98%", label: "Success", color: "accent" },
                            { value: "450+", label: "Rankers", color: "primary" },
                            { value: "35+", label: "Branches", color: "accent" }
                        ],
                        featuresList: [
                            "Expert Faculty with 15+ Years Experience",
                            "Comprehensive Study Material & Notes",
                            "Regular Mock Tests & Assessments",
                            "Doubt Clearing Sessions",
                            "Online + Offline Classes",
                            "Placement Assistance"
                        ],
                        featuresTitle: fetchedContent.whyChooseUs?.featuresTitle || "What You Get"
                    };
                }

                // Initialize onlineExperience if missing fields
                if (fetchedContent.onlineExperience) {
                    if (!fetchedContent.onlineExperience.videoUrl) {
                        fetchedContent.onlineExperience.videoUrl = "https://www.youtube.com/watch?v=3V1NGxcVdkI";
                    }
                }

                // Initialize testimonials if missing/empty
                if (!fetchedContent.testimonials?.list || fetchedContent.testimonials.list.length === 0) {
                    fetchedContent.testimonials = {
                        ...fetchedContent.testimonials,
                        list: [
                            {
                                name: "Priya Sharma",
                                rank: "AIR 45, CA Final",
                                image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=200",
                                text: "The faculty's expertise and personalized attention helped me secure top rank."
                            },
                            {
                                name: "Rahul Desai",
                                rank: "Distinction, CS Executive",
                                image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=200",
                                text: "Comprehensive material and mock tests gave me confidence to clear in first attempt."
                            },
                            {
                                name: "Anjali Patel",
                                rank: "AIR 122, CMA Inter",
                                image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=200",
                                text: "Blended learning approach helped me balance work and studies perfectly."
                            },
                            {
                                name: "Karan Mehta",
                                rank: "Distinction, CA Foundation",
                                image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=200",
                                text: "Best decision for my career. Teachers are always available for doubt clearing."
                            }
                        ]
                    };
                }

                // Initialize hero videos if missing/empty
                if (!fetchedContent.hero.videos || fetchedContent.hero.videos.length === 0) {
                    fetchedContent.hero.videos = Array(5).fill(null).map(() => ({
                        thumbnail: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800',
                        videoUrl: 'https://www.youtube.com/watch?v=3V1NGxcVdkI'
                    }));
                } else if (fetchedContent.hero.videos.length < 5) {
                    const extra = Array(5 - fetchedContent.hero.videos.length).fill(null).map(() => ({
                        thumbnail: '',
                        videoUrl: ''
                    }));
                    fetchedContent.hero.videos = [...fetchedContent.hero.videos, ...extra];
                }

                setContent(fetchedContent);
            } else {
                toast.error("Failed to load content");
            }
        } catch (error) {
            toast.error("Error connecting to server");
        } finally {
            setLoading(false);
        }
    };

    const handleSave = async () => {
        try {
            setSaving(true);
            const { ok, data } = await landingPageApi.updateLandingContent(content);
            if (ok && data.success) {
                toast.success("Content updated successfully");
                setContent(data.data);
            } else {
                toast.error("Failed to update content");
            }
        } catch (error) {
            toast.error("Error saving content");
        } finally {
            setSaving(false);
        }
    };

    const updateField = (path: string, value: any) => {
        const keys = path.split('.');
        setContent((prev: any) => {
            if (!prev) return prev;
            // Create a deep copy to ensure nested updates trigger re-renders and don't mutate
            const newState = JSON.parse(JSON.stringify(prev));
            let current = newState;
            for (let i = 0; i < keys.length - 1; i++) {
                if (current[keys[i]] === undefined) {
                    current[keys[i]] = {};
                }
                current = current[keys[i]];
            }
            current[keys[keys.length - 1]] = value;
            return newState;
        });
    };

    if (loading) {
        return <div className="flex justify-center items-center h-96"><Loader2 className="animate-spin h-8 w-8 text-primary" /></div>;
    }

    if (!content) return null;

    return (
        <div className="space-y-6 pb-20">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold tracking-tight">Landing Page Content</h2>
                    <p className="text-muted-foreground">Manage text, images, and sections of the homepage.</p>
                </div>
                <Button onClick={handleSave} disabled={saving}>
                    {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    <Save className="mr-2 h-4 w-4" />
                    Save Changes
                </Button>
            </div>

            <Tabs defaultValue="hero" className="w-full">
                <TabsList className="grid w-full grid-cols-4 lg:grid-cols-7 mb-8">
                    <TabsTrigger className="data-[state=active]:bg-red-600 data-[state=active]:text-white" value="hero">Hero</TabsTrigger>
                    {/* <TabsTrigger className="data-[state=active]:bg-red-600 data-[state=active]:text-white" value="programs">Programs</TabsTrigger> */}
                    <TabsTrigger className="data-[state=active]:bg-red-600 data-[state=active]:text-white" value="online">Online Exp</TabsTrigger>
                    <TabsTrigger className="data-[state=active]:bg-red-600 data-[state=active]:text-white" value="why">Why Us</TabsTrigger>
                    <TabsTrigger className="data-[state=active]:bg-red-600 data-[state=active]:text-white" value="testimonials">Stories</TabsTrigger>

                    <TabsTrigger className="data-[state=active]:bg-red-600 data-[state=active]:text-white" value="footer">Footer</TabsTrigger>
                </TabsList>

                {/* Hero Section */}
                <TabsContent value="hero" className="space-y-4">
                    <Card>
                        <CardHeader>
                            <CardTitle>Hero Section</CardTitle>
                            <CardDescription>Main banner and introduction.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid gap-4">
                                <div className="space-y-2">
                                    <Label>Badge Text</Label>
                                    <Input
                                        value={content.hero.badge}
                                        onChange={(e) => updateField('hero.badge', e.target.value)}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Main Title</Label>
                                    <Input
                                        value={content.hero.title}
                                        onChange={(e) => updateField('hero.title', e.target.value)}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Description</Label>
                                    <Textarea
                                        value={content.hero.description}
                                        onChange={(e) => updateField('hero.description', e.target.value)}
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label>Demo Button Text</Label>
                                        <Input
                                            value={content.hero.ctaDemoText}
                                            onChange={(e) => updateField('hero.ctaDemoText', e.target.value)}
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Courses Button Text</Label>
                                        <Input
                                            value={content.hero.ctaCoursesText}
                                            onChange={(e) => updateField('hero.ctaCoursesText', e.target.value)}
                                        />
                                    </div>
                                </div>
                                <div className="border-t pt-4">
                                    <h3 className="text-sm font-medium mb-4">Hero Videos (Exactly 5)</h3>
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                        {content.hero.videos?.slice(0, 5).map((video: any, index: number) => (
                                            <div key={index} className="space-y-4 p-4 bg-muted/20 rounded-lg border relative">
                                                <div className="absolute -top-2 -left-2 bg-primary text-white w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shadow-sm">
                                                    {index + 1}
                                                </div>
                                                <div className="space-y-2">
                                                    <ImageUpload
                                                        label={`Thumbnail ${index + 1}`}
                                                        value={video.thumbnail || ""}
                                                        onChange={(url) => updateField(`hero.videos.${index}.thumbnail`, url)}
                                                    />
                                                </div>
                                                <div className="space-y-2">
                                                    <Label className="text-xs">Video URL {index + 1}</Label>
                                                    <Input
                                                        value={video.videoUrl}
                                                        onChange={(e) => updateField(`hero.videos.${index}.videoUrl`, e.target.value)}
                                                        placeholder="https://www.youtube.com/watch?v=..."
                                                        className="h-8"
                                                    />
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                <div className="border-t pt-4">
                                    <h3 className="text-sm font-medium mb-4">Hero Stats (3 items)</h3>
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        {content.hero.stats?.map((stat: any, index: number) => (
                                            <div key={index} className="space-y-2 p-3 bg-muted/20 rounded-md border">
                                                <div className="space-y-1">
                                                    <Label className="text-xs">Value {index + 1}</Label>
                                                    <Input
                                                        value={stat.value}
                                                        onChange={(e) => updateField(`hero.stats.${index}.value`, e.target.value)}
                                                        className="h-8"
                                                    />
                                                </div>
                                                <div className="space-y-1">
                                                    <Label className="text-xs">Label {index + 1}</Label>
                                                    <Input
                                                        value={stat.label}
                                                        onChange={(e) => updateField(`hero.stats.${index}.label`, e.target.value)}
                                                        className="h-8"
                                                    />
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                <div className="border-t pt-4">
                                    <h3 className="text-sm font-medium mb-4">Quick Info Cards (2 items)</h3>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        {content.hero.quickInfo?.map((info: any, index: number) => (
                                            <div key={index} className="space-y-2 p-3 bg-muted/20 rounded-md border">
                                                <div className="space-y-1">
                                                    <Label className="text-xs">Label {index + 1}</Label>
                                                    <Input
                                                        value={info.label}
                                                        onChange={(e) => updateField(`hero.quickInfo.${index}.label`, e.target.value)}
                                                        className="h-8"
                                                    />
                                                </div>
                                                <div className="space-y-1">
                                                    <Label className="text-xs">Value {index + 1}</Label>
                                                    <Input
                                                        value={info.value}
                                                        onChange={(e) => updateField(`hero.quickInfo.${index}.value`, e.target.value)}
                                                        className="h-8"
                                                    />
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Programs Section */}
                {/* <TabsContent value="programs" className="space-y-4">
                    <Card>
                        <CardHeader>
                            <CardTitle>Popular Programs</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label>Section Title</Label>
                                <Input
                                    value={content.popularPrograms.title}
                                    onChange={(e) => updateField('popularPrograms.title', e.target.value)}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Subtitle</Label>
                                <Input
                                    value={content.popularPrograms.subtitle}
                                    onChange={(e) => updateField('popularPrograms.subtitle', e.target.value)}
                                />
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent> */}

                {/* Online Experience Section */}
                <TabsContent value="online" className="space-y-4">
                    <Card>
                        <CardHeader>
                            <CardTitle>Online Learning Experience</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label>Badge</Label>
                                <Input
                                    value={content.onlineExperience.badge}
                                    onChange={(e) => updateField('onlineExperience.badge', e.target.value)}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Title</Label>
                                <Input
                                    value={content.onlineExperience.title}
                                    onChange={(e) => updateField('onlineExperience.title', e.target.value)}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Description</Label>
                                <Textarea
                                    value={content.onlineExperience.description}
                                    onChange={(e) => updateField('onlineExperience.description', e.target.value)}
                                />
                            </div>
                            <div className="space-y-2">
                                <ImageUpload
                                    label="Side Image"
                                    value={content.onlineExperience.image || ""}
                                    onChange={(url) => updateField('onlineExperience.image', url)}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Platform Demo Video URL (YouTube/Vimeo)</Label>
                                <Input
                                    value={content.onlineExperience.videoUrl}
                                    onChange={(e) => updateField('onlineExperience.videoUrl', e.target.value)}
                                    placeholder="https://www.youtube.com/embed/..."
                                />
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                {/* Why Choose Us */}
                <TabsContent value="why" className="space-y-4">
                    <Card>
                        <CardHeader>
                            <CardTitle>Why Choose Us</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label>Main Title</Label>
                                <Input
                                    value={content.whyChooseUs.title}
                                    onChange={(e) => updateField('whyChooseUs.title', e.target.value)}
                                />
                            </div>

                            <div className="border-t pt-4">
                                <h3 className="text-sm font-medium mb-4">Stats Grid (4 items)</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {content.whyChooseUs.statsGrid?.map((stat: any, index: number) => (
                                        <div key={index} className="space-y-2 p-3 bg-muted/20 rounded-md border">
                                            <div className="space-y-1">
                                                <Label className="text-xs">Value {index + 1}</Label>
                                                <Input
                                                    value={stat.value}
                                                    onChange={(e) => updateField(`whyChooseUs.statsGrid.${index}.value`, e.target.value)}
                                                    className="h-8"
                                                />
                                            </div>
                                            <div className="space-y-1">
                                                <Label className="text-xs">Label {index + 1}</Label>
                                                <Input
                                                    value={stat.label}
                                                    onChange={(e) => updateField(`whyChooseUs.statsGrid.${index}.label`, e.target.value)}
                                                    className="h-8"
                                                />
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="border-t pt-4">
                                <div className="flex items-center justify-between mb-2">
                                    <h3 className="text-sm font-medium">Features List ("What You Get")</h3>
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => {
                                            const newList = [...(content.whyChooseUs.featuresList || [])];
                                            newList.push("New Feature");
                                            updateField('whyChooseUs.featuresList', newList);
                                        }}
                                    >
                                        <Plus className="h-3 w-3 mr-1" /> Add Feature
                                    </Button>
                                </div>
                                <div className="space-y-2">
                                    <Label>Features Title</Label>
                                    <Input
                                        value={content.whyChooseUs.featuresTitle}
                                        onChange={(e) => updateField('whyChooseUs.featuresTitle', e.target.value)}
                                    />
                                </div>
                                <div className="space-y-2 mt-2">
                                    {content.whyChooseUs.featuresList?.map((feature: string, index: number) => (
                                        <div key={index} className="flex gap-2">
                                            <Input
                                                value={feature}
                                                onChange={(e) => updateField(`whyChooseUs.featuresList.${index}`, e.target.value)}
                                            />
                                            <Button
                                                variant="ghost"
                                                size="icon"
                                                className="text-destructive hover:text-destructive/90 hover:bg-destructive/10 shrink-0"
                                                onClick={() => {
                                                    const newList = content.whyChooseUs.featuresList.filter((_: any, i: number) => i !== index);
                                                    updateField('whyChooseUs.featuresList', newList);
                                                }}
                                            >
                                                <Trash2 className="h-4 w-4" />
                                            </Button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="testimonials" className="space-y-4">
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between">
                            <div className="space-y-1.5">
                                <CardTitle>Student Success Stories</CardTitle>
                                <CardDescription>Manage student reviews and rankings displayed on the landing page.</CardDescription>
                            </div>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                    const newList = [...(content.testimonials?.list || [])];
                                    newList.push({
                                        name: "New Student",
                                        rank: "Rank/Exam Details",
                                        text: "Student review text...",
                                        image: ""
                                    });
                                    updateField('testimonials.list', newList);
                                }}
                            >
                                <Plus className="h-4 w-4 mr-2" />
                                Add Story
                            </Button>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="space-y-2">
                                <Label>Section Title</Label>
                                <Input
                                    value={content.testimonials?.title || "Student Success Stories"}
                                    onChange={(e) => updateField('testimonials.title', e.target.value)}
                                />
                            </div>

                            <div className="grid grid-cols-1 gap-6">
                                {content.testimonials?.list?.map((story: any, index: number) => (
                                    <div key={index} className="flex gap-4 p-4 bg-muted/20 rounded-lg border relative group">
                                        <div className="space-y-4 flex-1">
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                <div className="space-y-2">
                                                    <Label>Student Name</Label>
                                                    <Input
                                                        value={story.name}
                                                        onChange={(e) => updateField(`testimonials.list.${index}.name`, e.target.value)}
                                                        placeholder="e.g. Priya Sharma"
                                                    />
                                                </div>
                                                <div className="space-y-2">
                                                    <Label>Rank / Exam</Label>
                                                    <Input
                                                        value={story.rank}
                                                        onChange={(e) => updateField(`testimonials.list.${index}.rank`, e.target.value)}
                                                        placeholder="e.g. AIR 45, CA Final"
                                                    />
                                                </div>
                                            </div>
                                            <div className="space-y-2">
                                                <Label>Review Text</Label>
                                                <Textarea
                                                    value={story.text}
                                                    onChange={(e) => updateField(`testimonials.list.${index}.text`, e.target.value)}
                                                    placeholder="The student's feedback..."
                                                />
                                            </div>
                                        </div>

                                        <div className="w-32 space-y-2">
                                            <ImageUpload
                                                label="Photo"
                                                value={story.image || ""}
                                                onChange={(url) => updateField(`testimonials.list.${index}.image`, url)}
                                            />
                                        </div>

                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            className="absolute top-2 right-2 text-destructive hover:text-destructive/90 hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-opacity"
                                            onClick={() => {
                                                const newList = content.testimonials.list.filter((_: any, i: number) => i !== index);
                                                updateField('testimonials.list', newList);
                                            }}
                                        >
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                ))}

                                {(!content.testimonials?.list || content.testimonials.list.length === 0) && (
                                    <div className="text-center py-8 text-muted-foreground border-2 border-dashed rounded-lg">
                                        No stories added yet. Click "Add Story" to begin.
                                    </div>
                                )}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>


                {/* Footer CTA */}
                <TabsContent value="footer" className="space-y-4">
                    <Card>
                        <CardHeader>
                            <CardTitle>Footer CTA</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label>Title</Label>
                                <Input
                                    value={content.footerCta.title}
                                    onChange={(e) => updateField('footerCta.title', e.target.value)}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Description</Label>
                                <Textarea
                                    value={content.footerCta.description}
                                    onChange={(e) => updateField('footerCta.description', e.target.value)}
                                />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>Primary Button Text</Label>
                                    <Input
                                        value={content.footerCta.demoButtonText}
                                        onChange={(e) => updateField('footerCta.demoButtonText', e.target.value)}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Secondary Button Text</Label>
                                    <Input
                                        value={content.footerCta.brochureButtonText}
                                        onChange={(e) => updateField('footerCta.brochureButtonText', e.target.value)}
                                    />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <FileUpload
                                    label="Brochure PDF"
                                    value={content.footerCta.brochureUrl || ""}
                                    onChange={(url) => updateField('footerCta.brochureUrl', url)}
                                />
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

            </Tabs>
        </div >
    );
}
