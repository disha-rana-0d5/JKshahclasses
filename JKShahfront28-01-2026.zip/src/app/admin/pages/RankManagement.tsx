import { useState } from "react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "../../components/ui/dialog";
import { Label } from "../../components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Plus, Pencil, Trash2, Search } from "lucide-react";
import { useCourseContext, RankHolder } from "../context/CourseContext";
import { ImageUpload } from "../../components/ImageUpload";

export function RankManagement() {
    const { rankHolders, categories, addRankHolder, updateRankHolder, deleteRankHolder, loading } = useCourseContext();
    const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
    const [editingRank, setEditingRank] = useState<RankHolder | null>(null);
    const [searchQuery, setSearchQuery] = useState("");
    const [categoryFilter, setCategoryFilter] = useState("All");

    const [formData, setFormData] = useState<Partial<RankHolder>>({
        name: "",
        image: "",
        category: "",
        globalRank: "",
        indiaRank: "",
        course: "",
        session: ""
    });

    const filteredRanks = rankHolders.filter(rank => {
        const matchesSearch = rank.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            rank.course.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesCategory = categoryFilter === "All" || rank.category === categoryFilter;
        return matchesSearch && matchesCategory;
    });

    const handleOpenAdd = () => {
        setEditingRank(null);
        setFormData({
            name: "",
            image: "",
            category: categories[0]?.name || "",
            globalRank: "",
            indiaRank: "",
            course: "",
            session: ""
        });
        setIsAddDialogOpen(true);
    };

    const handleOpenEdit = (rank: RankHolder) => {
        setEditingRank(rank);
        setFormData(rank);
        setIsAddDialogOpen(true);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (editingRank) {
            await updateRankHolder(editingRank._id, formData);
        } else {
            await addRankHolder(formData);
        }
        setIsAddDialogOpen(false);
    };

    if (loading) {
        return <div className="flex items-center justify-center min-h-[400px]">Loading rank holders...</div>;
    }

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold tracking-tight text-foreground">Rank Holder Management</h2>
                    <p className="text-muted-foreground">Manage and showcase your top-performing students.</p>
                </div>
                <Button onClick={handleOpenAdd}>
                    <Plus className="mr-2 h-4 w-4" /> Add Rank Holder
                </Button>
            </div>

            <div className="flex flex-col md:flex-row items-end md:items-center justify-between gap-4 mb-4">
                <div className="relative flex-1 w-full md:max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                        placeholder="Search by name or course..."
                        className="pl-9"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>

                <div className="w-full md:w-48">
                    <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                        <SelectTrigger>
                            <SelectValue placeholder="Filter by Sub-Category" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="All">All Sub-Categories</SelectItem>
                            {categories.filter(c => c.parent).map((cat) => (
                                <SelectItem key={cat._id} value={cat.name}>{cat.name}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </div>

            <div className="rounded-md border border-border bg-white">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="w-[80px]">Image</TableHead>
                            <TableHead>Student Name</TableHead>
                            <TableHead>Sub-Category</TableHead>
                            <TableHead>Global Rank</TableHead>
                            <TableHead>India Rank</TableHead>
                            <TableHead>Course</TableHead>
                            <TableHead>Session</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {filteredRanks.length > 0 ? (
                            filteredRanks.map((rank) => (
                                <TableRow key={rank._id}>
                                    <TableCell>
                                        <img src={rank.image} alt={rank.name} className="w-10 h-10 rounded-full object-cover bg-gray-100" />
                                    </TableCell>
                                    <TableCell className="font-medium">{rank.name}</TableCell>
                                    <TableCell>{rank.category}</TableCell>
                                    <TableCell>{rank.globalRank}</TableCell>
                                    <TableCell>{rank.indiaRank}</TableCell>
                                    <TableCell>{rank.course}</TableCell>
                                    <TableCell>{rank.session}</TableCell>
                                    <TableCell className="text-right">
                                        <div className="flex justify-end gap-2">
                                            <Button variant="ghost" size="icon" onClick={() => handleOpenEdit(rank)}>
                                                <Pencil className="h-4 w-4" />
                                            </Button>
                                            <Button variant="ghost" size="icon" onClick={() => deleteRankHolder(rank._id)}>
                                                <Trash2 className="h-4 w-4 text-destructive" />
                                            </Button>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ))
                        ) : (
                            <TableRow>
                                <TableCell colSpan={8} className="h-24 text-center text-muted-foreground italic">
                                    No rank holders found.
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>

            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogContent className="sm:max-w-[600px]">
                    <DialogHeader>
                        <DialogTitle>{editingRank ? "Edit Rank Holder" : "Add New Rank Holder"}</DialogTitle>
                        <DialogDescription>
                            Enter the details of the student who achieved a top rank.
                        </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="space-y-4 py-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2 col-span-2">
                                <Label htmlFor="name">Student Name</Label>
                                <Input
                                    id="name"
                                    value={formData.name}
                                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                    required
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="category">Sub-Category</Label>
                                <Select
                                    value={formData.category}
                                    onValueChange={(val) => setFormData({ ...formData, category: val })}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select sub-category" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {categories.filter(c => c.parent).map((cat) => (
                                            <SelectItem key={cat._id} value={cat.name}>{cat.name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="course">Course/Subject</Label>
                                <Input
                                    id="course"
                                    placeholder="e.g. AAA, Audit, etc."
                                    value={formData.course}
                                    onChange={(e) => setFormData({ ...formData, course: e.target.value })}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="globalRank">Global Rank</Label>
                                <Input
                                    id="globalRank"
                                    placeholder="e.g. 11"
                                    value={formData.globalRank}
                                    onChange={(e) => setFormData({ ...formData, globalRank: e.target.value })}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="indiaRank">India Rank</Label>
                                <Input
                                    id="indiaRank"
                                    placeholder="e.g. 03"
                                    value={formData.indiaRank}
                                    onChange={(e) => setFormData({ ...formData, indiaRank: e.target.value })}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="session">Session</Label>
                                <Input
                                    id="session"
                                    placeholder="e.g. June 2021"
                                    value={formData.session}
                                    onChange={(e) => setFormData({ ...formData, session: e.target.value })}
                                />
                            </div>
                            <div className="space-y-2">
                                <ImageUpload
                                    label="Student Image"
                                    value={formData.image || ""}
                                    onChange={(url) => setFormData({ ...formData, image: url })}
                                />
                            </div>
                        </div>
                        <DialogFooter>
                            <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancel</Button>
                            <Button type="submit">{editingRank ? "Save Changes" : "Add Rank Holder"}</Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        </div>
    );
}
