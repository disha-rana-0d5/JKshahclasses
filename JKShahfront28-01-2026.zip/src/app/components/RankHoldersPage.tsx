import { useState } from "react";
import { useCourseContext, RankHolder } from "../admin/context/CourseContext";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Search, Trophy, Medal, Star } from "lucide-react";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";

export function RankHoldersPage() {
    const { rankHolders, categories } = useCourseContext();
    const [searchQuery, setSearchQuery] = useState("");
    const [selectedCategory, setSelectedCategory] = useState("All");

    const filteredRanks = rankHolders.filter(rank => {
        const matchesSearch = rank.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            rank.course.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesCategory = selectedCategory === "All" || rank.category === selectedCategory;
        return matchesSearch && matchesCategory;
    });

    const activeCategories = ["All", ...Array.from(new Set(rankHolders.map(r => r.category)))];

    return (
        <div className="min-h-screen bg-slate-50/50 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
                <div className="text-center mb-12">
                    <div className="inline-flex items-center justify-center p-2 bg-primary/10 rounded-full mb-4">
                        <Trophy className="w-6 h-6 text-primary" />
                    </div>
                    <h1 className="text-4xl md:text-5xl font-black text-slate-900 mb-4 tracking-tight">Our Rank Holders</h1>
                    <p className="text-lg text-slate-600 max-w-2xl mx-auto">Celebrating the extraordinary achievements of our students who leading the way globally and nationally.</p>
                </div>

                <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-12 bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
                    <div className="relative w-full md:max-w-md">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                        <Input
                            placeholder="Search by name or course..."
                            className="pl-11 h-12 bg-slate-50 border-none rounded-xl focus-visible:ring-primary/20"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </div>

                    <div className="flex gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-hide">
                        {activeCategories.map(cat => (
                            <button
                                key={cat}
                                onClick={() => setSelectedCategory(cat)}
                                className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-all ${selectedCategory === cat
                                    ? "bg-primary text-white shadow-lg shadow-primary/25"
                                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                                    }`}
                            >
                                {cat}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                    {filteredRanks.map((rank) => (
                        <div key={rank._id} className="group bg-white rounded-[2rem] overflow-hidden shadow-xl shadow-slate-200/50 border border-slate-100 transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl hover:shadow-primary/10">
                            {/* Rank Header */}
                            <div className="flex h-16">
                                <div className="flex-1 bg-[#373081] flex items-center justify-center text-white gap-2 p-2 rounded-tl-[2rem] border-r border-white/10">
                                    <span className="text-[10px] opacity-70 uppercase tracking-widest font-extrabold">Global :</span>
                                    <span className="text-2xl font-black">{rank.globalRank}</span>
                                </div>
                                <div className="flex-1 bg-gradient-to-br from-[#373081] to-[#4a4399] flex items-center justify-center text-white gap-2 p-2">
                                    <span className="text-[10px] opacity-70 uppercase tracking-widest font-extrabold">India :</span>
                                    <span className="text-2xl font-black">{rank.indiaRank}</span>
                                </div>
                            </div>

                            <div className="p-8 flex flex-col items-center text-center relative">
                                <div className="absolute top-0 left-0 w-full h-2 bg-white -mt-1 rounded-full z-10" />

                                <div className="relative mb-6">
                                    <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-slate-50 shadow-inner group-hover:border-primary/20 transition-colors">
                                        <ImageWithFallback
                                            src={rank.image}
                                            alt={rank.name}
                                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                                        />
                                    </div>
                                    <div className="absolute -bottom-2 -right-2 bg-amber-400 p-2 rounded-full shadow-lg border-2 border-white">
                                        <Medal className="w-5 h-5 text-amber-900" />
                                    </div>
                                </div>

                                <h3 className="text-xl font-black text-slate-800 mb-2">{rank.name}</h3>
                                <div className="flex flex-col gap-1">
                                    <p className="text-sm font-bold text-slate-500">
                                        ({rank.course}) {rank.session}
                                    </p>
                                    <div className="mt-4">
                                        <Badge variant="secondary" className="bg-primary/5 text-primary border-none font-bold uppercase tracking-tighter text-[10px] px-3 py-1">
                                            {rank.category} ACHIEVER
                                        </Badge>
                                    </div>
                                </div>
                            </div>

                            {/* Bottom Swirl Pattern - Styled Card */}
                            <div className="h-4 bg-slate-50 w-full rounded-br-[2rem]" />
                        </div>
                    ))}
                </div>

                {filteredRanks.length === 0 && (
                    <div className="text-center py-24 bg-white rounded-3xl border border-dashed border-slate-200">
                        <div className="bg-slate-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Star className="w-10 h-10 text-slate-300" />
                        </div>
                        <h3 className="text-xl font-bold text-slate-800 mb-2">No Rank Holders Found</h3>
                        <p className="text-slate-500">Try adjusting your filters or search query.</p>
                    </div>
                )}
            </div>

            {/* Background Decorations */}
            <div className="fixed top-0 right-0 -z-10 w-[500px] h-[500px] bg-primary/5 rounded-full blur-3xl opacity-50 translate-x-1/2 -translate-y-1/2" />
            <div className="fixed bottom-0 left-0 -z-10 w-[400px] h-[400px] bg-accent/5 rounded-full blur-3xl opacity-50 -translate-x-1/2 translate-y-1/2" />
        </div>
    );
}
