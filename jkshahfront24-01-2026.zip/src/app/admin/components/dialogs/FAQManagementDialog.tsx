import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../../components/ui/select";
import { Textarea } from "../../../components/ui/textarea";
import { Plus, Trash2 } from "lucide-react";

import { Course, Category } from "../../context/CourseContext";

interface FAQManagementDialogProps {
    isOpen: boolean;
    onClose: () => void;
    course: Course | null;
    categories: Category[];
    onSave: (courseId: string, faqs: any[]) => Promise<void>;
}

export function FAQManagementDialog({ isOpen, onClose, course, categories, onSave }: FAQManagementDialogProps) {
    const [faqData, setFaqData] = useState<{ category: string; questions: { question: string; answer: string; }[] }[]>([]);
    const [newFaqCategory, setNewFaqCategory] = useState("");

    useEffect(() => {
        if (course && isOpen) {
            setFaqData(course.faqs ? JSON.parse(JSON.stringify(course.faqs)) : []); // Deep copy to avoid direct mutation
            setNewFaqCategory("");
        }
    }, [course, isOpen]);

    const handleSave = async () => {
        if (!course) return;
        await onSave(course._id, faqData);
        onClose();
    };

    return (
        <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
            <DialogContent className="sm:max-w-[800px] max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>Manage Course FAQs</DialogTitle>
                    <DialogDescription>
                        Add frequently asked questions organized by categories for <span className="font-semibold text-primary">{course?.title}</span>.
                    </DialogDescription>
                </DialogHeader>

                <div className="space-y-6 py-4">
                    <div className="flex items-center gap-2 bg-muted/30 p-4 rounded-lg border border-border">
                        <div className="flex-1">
                            <Select value={newFaqCategory} onValueChange={setNewFaqCategory}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select Category for FAQs" />
                                </SelectTrigger>
                                <SelectContent>
                                    {(categories || []).map((cat) => (
                                        <SelectItem key={cat._id} value={cat.name}>{cat.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <Button
                            onClick={() => {
                                if (newFaqCategory.trim()) {
                                    // Check if category already exists in FAQ list
                                    if (!faqData.some(f => f.category === newFaqCategory)) {
                                        setFaqData([...faqData, { category: newFaqCategory.trim(), questions: [] }]);
                                    }
                                    setNewFaqCategory("");
                                }
                            }}
                            disabled={!newFaqCategory.trim()}
                        >
                            <Plus className="w-4 h-4 mr-2" /> Add Section
                        </Button>
                    </div>

                    {faqData.length === 0 ? (
                        <div className="text-center py-8 text-muted-foreground border-2 border-dashed rounded-lg">
                            No FAQs added yet. Select a category above to start adding questions.
                        </div>
                    ) : (
                        <div className="space-y-6">
                            {faqData.map((category, catIdx) => (
                                <div key={catIdx} className="border border-border rounded-lg overflow-hidden">
                                    <div className="bg-muted px-4 py-3 flex items-center justify-between">
                                        <h3 className="font-semibold">{category.category}</h3>
                                        <Button
                                            variant="ghost"
                                            size="sm"
                                            onClick={() => setFaqData(faqData.filter((_, i) => i !== catIdx))}
                                            className="text-destructive hover:text-destructive hover:bg-destructive/10"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </Button>
                                    </div>
                                    <div className="p-4 bg-white space-y-4">
                                        {category.questions.map((q, qIdx) => (
                                            <div key={qIdx} className="flex gap-3 items-start p-3 bg-muted/10 rounded-lg border border-border/50">
                                                <div className="flex-1 space-y-2">
                                                    <Input
                                                        placeholder="Question"
                                                        value={q.question}
                                                        onChange={(e) => {
                                                            const newData = [...faqData];
                                                            newData[catIdx].questions[qIdx].question = e.target.value;
                                                            setFaqData(newData);
                                                        }}
                                                        className="font-medium"
                                                    />
                                                    <Textarea
                                                        placeholder="Answer"
                                                        value={q.answer}
                                                        onChange={(e) => {
                                                            const newData = [...faqData];
                                                            newData[catIdx].questions[qIdx].answer = e.target.value;
                                                            setFaqData(newData);
                                                        }}
                                                        className="text-sm text-muted-foreground"
                                                    />
                                                </div>
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    onClick={() => {
                                                        const newData = [...faqData];
                                                        newData[catIdx].questions = newData[catIdx].questions.filter((_, i) => i !== qIdx);
                                                        setFaqData(newData);
                                                    }}
                                                >
                                                    <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                                                </Button>
                                            </div>
                                        ))}
                                        <Button
                                            variant="outline"
                                            size="sm"
                                            onClick={() => {
                                                const newData = [...faqData];
                                                newData[catIdx].questions.push({ question: "", answer: "" });
                                                setFaqData(newData);
                                            }}
                                            className="w-full"
                                        >
                                            <Plus className="w-3 h-3 mr-2" /> Add Question
                                        </Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Cancel</Button>
                    <Button onClick={handleSave}>Save FAQs</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
