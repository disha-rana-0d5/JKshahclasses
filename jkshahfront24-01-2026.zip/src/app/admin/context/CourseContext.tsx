import React, { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { categoryApi, courseApi, levelApi, facultyApi } from "../../api/api";

import { toast } from "sonner";

export interface Course {
    _id: string;
    slug: string;
    title: string;
    description: string;
    category: string;
    subCategory: string;
    price: number;
    originalPrice?: number;
    duration: string;
    lessons: number;
    rating: number;
    reviews: number;
    facultyName: string;
    facultyImage: string;
    discount?: string;
    highlights: string[];
    tags: string[];
    enrolledTotal: number;
    enrolledRecent: number;
    status: "Active" | "Draft" | "Archived";
    image: string;
    batchInfo?: string;
    level: string;
    // New fields
    syllabusModules?: any[];
    facultyDesignation?: string;
    facultySpecialization?: string;
    facultyExperience?: string;
    facultyStudents?: string;
    facultyRating?: number;
    facultyBio?: string;
    courseFeatures?: string[];
    whatYouLearn?: string[];
    whoShouldEnroll?: string[];
    reviewsList?: {
        name: string;
        rating: number;
        date: string;
        text: string;
        achievement: string;
        image: string;
    }[];
    videos?: {
        title: string;
        url: string;
    }[];
    faqs?: {
        category: string;
        questions: {
            question: string;
            answer: string;
        }[];
    }[];
    testimonials?: {
        category: string;
        items: {
            name: string;
            message: string;
            image: string;
            designation: string;
            videoUrl: string;
        }[];
    }[];
    brochureUrl?: string;
    syllabusPdf?: string;
}

export interface Level {
    _id: string;
    name: string;
    description?: string;
}


export interface Category {
    _id: string;
    name: string;
    description?: string;
    parent?: string;
    whyTitle?: string;
    whyContent?: string;
    whyJKShahTitle?: string;
    whyJKShahContent?: string;
    slug?: string;
    metaTitle?: string;
    metaDescription?: string;
    metaKeywords?: string;
}

export interface Faculty {
    _id: string;
    name: string;
    designation: string;
    expertise: string;
    experience: number;
    rating: string;
    totalStudents: string;
    coursesTaught: string[];
    image: string;
    specialization: string;
    qualifications: string[];
    tagline: string;
    achievements: string[];
}

interface CourseContextType {
    courses: Course[];
    categories: Category[];
    levels: Level[];
    addCourse: (course: Partial<Course>) => Promise<void>;
    updateCourse: (id: string, course: Partial<Course>) => Promise<void>;
    deleteCourse: (id: string) => Promise<void>;
    addCategory: (name: string, description?: string, parent?: string, slug?: string, metaTitle?: string, metaDescription?: string, metaKeywords?: string) => Promise<void>;
    updateCategory: (id: string, data: Partial<Category>) => Promise<void>;
    deleteCategory: (id: string, name: string) => Promise<void>;
    addLevel: (name: string) => Promise<void>;
    deleteLevel: (id: string, name: string) => Promise<void>;
    faculties: Faculty[];
    loading: boolean;
}


const CourseContext = createContext<CourseContextType | undefined>(undefined);

export function CourseProvider({ children }: { children: ReactNode }) {
    const [courses, setCourses] = useState<Course[]>([]);
    const [categories, setCategories] = useState<Category[]>([]);
    const [levels, setLevels] = useState<Level[]>([]);
    const [faculties, setFaculties] = useState<Faculty[]>([]);
    const [loading, setLoading] = useState(true);


    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const [catRes, courseRes, levelRes, facultyRes] = await Promise.all([
                    categoryApi.getCategories(),
                    courseApi.getCourses(),
                    levelApi.getLevels(),
                    facultyApi.getFaculties()
                ]);

                if (catRes.ok && catRes.data.success) {
                    setCategories(catRes.data.data);
                }
                if (courseRes.ok && courseRes.data.success) {
                    setCourses(courseRes.data.data);
                }
                if (levelRes.ok && levelRes.data.success) {
                    setLevels(levelRes.data.data);
                }
                if (facultyRes.ok && facultyRes.data.success) {
                    setFaculties(facultyRes.data.data);
                }

            } catch (error) {
                console.error("Failed to fetch data:", error);
                toast.error("Failed to load data from server");
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    const addCourse = async (courseData: Partial<Course>) => {
        try {
            const { ok, data } = await courseApi.addCourse(courseData);
            if (ok && data.success) {
                setCourses((prev) => [...prev, data.data]);
                toast.success("Course added successfully");
            } else {
                toast.error(data.message || "Failed to add course");
            }
        } catch (error) {
            toast.error("Failed to connect to server");
        }
    };

    const updateCourse = async (id: string, courseData: Partial<Course>) => {
        try {
            const { ok, data } = await courseApi.updateCourse(id, courseData);
            if (ok && data.success) {
                setCourses((prev) => prev.map(c => c._id === id ? data.data : c));
                toast.success("Course updated successfully");
            } else {
                toast.error(data.message || "Failed to update course");
            }
        } catch (error) {
            toast.error("Failed to connect to server");
        }
    };

    const deleteCourse = async (id: string) => {
        if (confirm("Are you sure you want to delete this course?")) {
            try {
                const { ok, data } = await courseApi.deleteCourse(id);
                if (ok && data.success) {
                    setCourses((prev) => prev.filter(c => c._id !== id));
                    toast.success("Course deleted successfully");
                } else {
                    toast.error(data.message || "Failed to delete course");
                }
            } catch (error) {
                toast.error("Failed to connect to server");
            }
        }
    };

    const addCategory = async (name: string, description?: string, parent?: string, slug?: string, metaTitle?: string, metaDescription?: string, metaKeywords?: string) => {
        if (!name.trim()) return;

        try {
            const { ok, data } = await categoryApi.addCategory(name.trim(), description, parent, slug, metaTitle, metaDescription, metaKeywords);
            if (ok && data.success) {
                setCategories((prev) => [...prev, data.data]);
                toast.success("Category added successfully");
            } else {
                toast.error(data.message || "Failed to add category");
            }
        } catch (error) {
            toast.error("Failed to connect to server");
        }
    };

    const updateCategory = async (id: string, categoryData: Partial<Category>) => {
        try {
            const { ok, data } = await categoryApi.updateCategory(id, categoryData);
            if (ok && data.success) {
                setCategories((prev) => prev.map(c => c._id === id ? data.data : c));
                toast.success("Category updated successfully");
            } else {
                toast.error(data.message || "Failed to update category");
            }
        } catch (error) {
            toast.error("Failed to connect to server");
        }
    };

    const deleteCategory = async (id: string, name: string) => {
        if (confirm(`Are you sure you want to delete category "${name}"?`)) {
            try {
                const { ok, data } = await categoryApi.deleteCategory(id);
                if (ok && data.success) {
                    setCategories((prev) => prev.filter((c) => c._id !== id));
                    setCourses(prev => prev.map(c => c.category === name ? { ...c, category: "Uncategorized" } : c));
                    toast.success("Category deleted successfully");
                } else {
                    toast.error(data.message || "Failed to delete category");
                }
            } catch (error) {
                toast.error("Failed to connect to server");
            }
        }
    };

    const addLevel = async (name: string) => {
        if (!name.trim()) return;

        try {
            const { ok, data } = await levelApi.addLevel(name.trim());
            if (ok && data.success) {
                setLevels((prev) => [...prev, data.data]);
                toast.success("Level added successfully");
            } else {
                toast.error(data.message || "Failed to add level");
            }
        } catch (error) {
            toast.error("Failed to connect to server");
        }
    };

    const deleteLevel = async (id: string, name: string) => {
        if (confirm(`Are you sure you want to delete level "${name}"?`)) {
            try {
                const { ok, data } = await levelApi.deleteLevel(id);
                if (ok && data.success) {
                    setLevels((prev) => prev.filter((l) => l._id !== id));
                    setCourses(prev => prev.map(c => c.level === name ? { ...c, level: "All" } : c));
                    toast.success("Level deleted successfully");
                } else {
                    toast.error(data.message || "Failed to delete level");
                }
            } catch (error) {
                toast.error("Failed to connect to server");
            }
        }
    };


    return (
        <CourseContext.Provider value={{ courses, categories, levels, faculties, addCourse, updateCourse, deleteCourse, addCategory, updateCategory, deleteCategory, addLevel, deleteLevel, loading }}>

            {children}
        </CourseContext.Provider>
    );
}

export function useCourseContext() {
    const context = useContext(CourseContext);
    if (!context) {
        throw new Error("useCourseContext must be used within a CourseProvider");
    }
    return context;
}
