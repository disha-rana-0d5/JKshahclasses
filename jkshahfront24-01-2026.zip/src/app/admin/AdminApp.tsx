import { AdminLayout } from "./layout/AdminLayout";
import { Dashboard } from "./pages/Dashboard";
import { CourseManagement } from "./pages/CourseManagement";
import { FacultyManagement } from "./pages/FacultyManagement";
import { UserManagement } from "./pages/UserManagement";
import { OrderManagement } from "./pages/OrderManagement";
import { LandingPageManagement } from "./pages/LandingPageManagement";
import { Reports } from "./pages/Reports";
import { CategoryManagement } from "./pages/CategoryManagement";
import { SubCategoryManagement } from "./pages/SubCategoryManagement";
import { LevelManagement } from "./pages/LevelManagement";
import { FooterManagement } from "./pages/FooterManagement";
import { BranchManagement } from "./pages/BranchManagement";
import { CourseFAQs } from "./pages/CourseFAQs";
import { CourseTestimonials } from "./pages/CourseTestimonials";
import { CourseVideos } from "./pages/CourseVideos";
import { CourseSyllabus } from "./pages/CourseSyllabus";

import { Button } from "../components/ui/button";
import { Routes, Route, Navigate } from "react-router-dom";

// Placeholders for other pages
const PlaceholderPage = ({ title }: { title: string }) => (
    <div className="min-h-[60vh] flex flex-col items-center justify-center p-8 text-center border-2 border-dashed border-gray-200 rounded-lg">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">{title}</h2>
        <p className="text-gray-500 mb-4">This module is currently under development.</p>
        <Button>Get Started</Button>
    </div>
);

export function AdminApp() {
    return (
        <AdminLayout>
            <Routes>
                <Route path="/" element={<Navigate to="dashboard" replace />} />
                <Route path="dashboard" element={<Dashboard />} />
                <Route path="courses" element={<CourseManagement />} />
                <Route path="faqs" element={<CourseFAQs />} />
                <Route path="testimonials" element={<CourseTestimonials />} />
                <Route path="videos" element={<CourseVideos />} />
                <Route path="syllabus" element={<CourseSyllabus />} />
                <Route path="categories" element={<CategoryManagement />} />
                <Route path="subcategories" element={<SubCategoryManagement />} />
                <Route path="levels" element={<LevelManagement />} />

                <Route path="faculty" element={<FacultyManagement />} />
                <Route path="users" element={<UserManagement />} />
                <Route path="orders" element={<OrderManagement />} />
                <Route path="content" element={<LandingPageManagement />} />
                <Route path="content/footer" element={<FooterManagement />} />
                <Route path="content/branches" element={<BranchManagement />} />
                <Route path="reports" element={<Reports />} />
            </Routes>
        </AdminLayout>
    );
}
