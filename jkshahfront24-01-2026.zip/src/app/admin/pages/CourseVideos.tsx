import { useState } from "react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../components/ui/table";
import { Badge } from "../../components/ui/badge";
import { Search, Video, Filter } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "../../components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Label } from "../../components/ui/label";
import { useCourseContext, Course } from "../context/CourseContext";
import { VideoManagementDialog } from "../components/dialogs/VideoManagementDialog";

export function CourseVideos() {
    const { courses, categories, levels, updateCourse, loading } = useCourseContext();

    // Video Dialog State
    const [isVideoDialogOpen, setIsVideoDialogOpen] = useState(false);
    const [selectedVideoCourse, setSelectedVideoCourse] = useState<Course | null>(null);

    const handleManageVideos = (course: Course) => {
        setSelectedVideoCourse(course);
        setIsVideoDialogOpen(true);
    };

    const handleSaveVideos = async (courseId: string, videos: any[]) => {
        await updateCourse(courseId, { videos });
    };

    // Filter Filters
    const [searchQuery, setSearchQuery] = useState("");
    const [categoryFilter, setCategoryFilter] = useState("All");
    const [levelFilter, setLevelFilter] = useState("All");
    const [statusFilter, setStatusFilter] = useState("All");

    const filteredCourses = courses.filter(course => {
        const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesCategory = categoryFilter === "All" || course.category === categoryFilter;
        const matchesLevel = levelFilter === "All" || course.level === levelFilter;
        const matchesStatus = statusFilter === "All" || course.status === statusFilter;
        return matchesSearch && matchesCategory && matchesLevel && matchesStatus;
    });

    const resetFilters = () => {
        setCategoryFilter("All");
        setLevelFilter("All");
        setStatusFilter("All");
    };

    if (loading) {
        return <div className="flex items-center justify-center min-h-[400px]">Loading courses...</div>;
    }

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold tracking-tight text-foreground">Course Demo Videos</h2>
                    <p className="text-muted-foreground">Manage demo videos for your courses.</p>
                </div>
            </div>

            <div className="flex flex-col md:flex-row items-end md:items-center justify-between gap-4 mb-4">
                <div className="relative flex-1 w-full md:max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                        placeholder="Search courses..."
                        className="pl-9"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>

                <Popover>
                    <PopoverTrigger asChild>
                        <Button variant="outline" className="gap-2">
                            <Filter className="h-4 w-4" />
                            Filters
                            {(categoryFilter !== "All" || levelFilter !== "All" || statusFilter !== "All") && (
                                <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-[10px]">Active</Badge>
                            )}
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-80" align="end">
                        <div className="space-y-4">
                            <div className="flex items-center justify-between">
                                <h4 className="font-medium leading-none">Filter Courses</h4>
                                <Button variant="ghost" size="sm" onClick={resetFilters} className="h-auto p-0 text-xs text-muted-foreground hover:text-primary">
                                    Reset
                                </Button>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="category">Category</Label>
                                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                                    <SelectTrigger id="category">
                                        <SelectValue placeholder="Select Category" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="All">All Categories</SelectItem>
                                        {categories.map((cat) => (
                                            <SelectItem key={cat._id} value={cat.name}>{cat.name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="level">Level</Label>
                                <Select value={levelFilter} onValueChange={setLevelFilter}>
                                    <SelectTrigger id="level">
                                        <SelectValue placeholder="Select Level" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="All">All Levels</SelectItem>
                                        {levels.map((lvl) => (
                                            <SelectItem key={lvl._id} value={lvl.name}>{lvl.name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="status">Visibility</Label>
                                <Select value={statusFilter} onValueChange={setStatusFilter}>
                                    <SelectTrigger id="status">
                                        <SelectValue placeholder="Select Visibility" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="All">All Visibility</SelectItem>
                                        <SelectItem value="Active">Active</SelectItem>
                                        <SelectItem value="Draft">Draft</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    </PopoverContent>
                </Popover>
            </div>

            <div className="rounded-md border border-border bg-white">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="w-[80px]">Image</TableHead>
                            <TableHead>Course Title</TableHead>
                            <TableHead>Category</TableHead>
                            <TableHead>Level</TableHead>
                            <TableHead>Video Title</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {filteredCourses.map((course) => (
                            <TableRow key={course._id}>
                                <TableCell>
                                    <img src={course.image} alt={course.title} className="w-10 h-10 rounded object-cover bg-gray-100" />
                                </TableCell>
                                <TableCell className="font-medium">
                                    {course.title}
                                    <p className="text-xs text-muted-foreground truncate max-w-[150px]">{course.description}</p>
                                </TableCell>
                                <TableCell>{course.category}</TableCell>
                                <TableCell>
                                    <Badge variant="outline">{course.level}</Badge>
                                </TableCell>
                                <TableCell>
                                    {course.videos && course.videos.length > 0 ? (
                                        <div className="flex flex-col">
                                            <span className="text-sm font-medium">{course.videos[0].title}</span>
                                            <span className="text-xs text-muted-foreground truncate max-w-[200px]">{course.videos[0].url}</span>
                                        </div>
                                    ) : (
                                        <span className="text-xs text-muted-foreground">No video set</span>
                                    )}
                                </TableCell>
                                <TableCell className="text-right">
                                    <Button variant="outline" size="sm" onClick={() => handleManageVideos(course)}>
                                        <Video className="mr-2 h-4 w-4" /> Manage Video
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>

            <VideoManagementDialog
                isOpen={isVideoDialogOpen}
                onClose={() => setIsVideoDialogOpen(false)}
                course={selectedVideoCourse}
                onSave={handleSaveVideos}
            />
        </div>
    );
}
