import { useState, useEffect } from "react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { landingPageApi, batchApi, categoryApi, levelApi } from "../../api/api";
import { toast } from "sonner";
import { Loader2, Save, MapPin, Plus, Trash2, Edit, Type, Layout, Calendar, Clock, BookOpen, GraduationCap, Laptop, Video, Trash } from "lucide-react";
import { Textarea } from "../../components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../components/ui/table";
import { ImageUpload } from "../../components/ImageUpload";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";

export function BranchManagement() {
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [content, setContent] = useState<any>(null);
    const [expandedBranch, setExpandedBranch] = useState<number | null>(null);
    const [batches, setBatches] = useState<any[]>([]);
    const [categories, setCategories] = useState<any[]>([]);
    const [levels, setLevels] = useState<any[]>([]);
    const [batchFormData, setBatchFormData] = useState({
        location: "",
        category: "",
        level: "",
        mode: "",
        startDate: "",
        dayTiming: "",
        examAttempt: ""
    });
    const [isAddingBatch, setIsAddingBatch] = useState(false);

    useEffect(() => {
        fetchContent();
        fetchBatches();
        fetchMetadata();
    }, []);

    const fetchMetadata = async () => {
        try {
            const [catRes, levelRes] = await Promise.all([
                categoryApi.getCategories(),
                levelApi.getLevels()
            ]);
            if (catRes.ok && catRes.data.success) {
                setCategories(catRes.data.data.filter((c: any) => c.parent));
            }
            if (levelRes.ok && levelRes.data.success) {
                setLevels(levelRes.data.data);
            }
        } catch (error) {
            console.error("Error fetching metadata:", error);
        }
    };

    const fetchBatches = async () => {
        try {
            const { ok, data } = await batchApi.getBatches();
            if (ok && data.success) {
                setBatches(data.data);
            }
        } catch (error) {
            console.error("Error fetching batches:", error);
        }
    };

    const fetchContent = async () => {
        try {
            setLoading(true);
            const { ok, data } = await landingPageApi.getLandingContent();
            if (ok && data.success) {
                let fetchedContent = data.data;
                // Initialize default branchPage if missing
                if (!fetchedContent.branchPage) {
                    fetchedContent.branchPage = {
                        header: {
                            badge: "35+ Branches Pan India",
                            title: "Find a Branch Near You",
                            description: "Visit our state-of-the-art learning centers equipped with modern facilities and experienced faculty"
                        },
                        stats: [
                            { value: "35+", label: "Branches Across India" },
                            { value: "50,000+", label: "Active Students" },
                            { value: "450+", label: "Rank Holders" },
                            { value: "98%", label: "Success Rate" }
                        ],
                        cta: {
                            title: "Visit Our Nearest Branch",
                            description: "Experience our world-class infrastructure and meet our expert faculty in person",
                            scheduleBtn: "Schedule a Visit",
                            downloadBtn: "Download Branch List"
                        }
                    };
                }

                // Initialize default branches if missing - REMOVED to keep it dynamic
                if (!fetchedContent.branches) {
                    fetchedContent.branches = [];
                }
                setContent(fetchedContent);
            } else {
                toast.error("Failed to load content");
            }
        } catch (error) {
            toast.error("Error connecting to server");
        } finally {
            setLoading(false);
        }
    };

    const handleSave = async () => {
        try {
            setSaving(true);
            const { ok, data } = await landingPageApi.updateLandingContent(content);
            if (ok && data.success) {
                toast.success("Branch content updated successfully");
                setContent(data.data);
            } else {
                toast.error("Failed to update content");
            }
        } catch (error) {
            toast.error("Error saving content");
        } finally {
            setSaving(false);
        }
    };

    const updateField = (path: string, value: any) => {
        const keys = path.split('.');
        setContent((prev: any) => {
            const newState = { ...prev };
            let current = newState;
            for (let i = 0; i < keys.length - 1; i++) {
                if (!current[keys[i]]) current[keys[i]] = {};
                current = current[keys[i]];
            }
            current[keys[keys.length - 1]] = value;
            return newState;
        });
    };

    const updateBranchField = (index: number, field: string, value: any) => {
        setContent((prev: any) => {
            const newBranches = [...(prev.branches || [])];
            newBranches[index] = { ...newBranches[index], [field]: value };
            return { ...prev, branches: newBranches };
        });
    };

    const addBranch = () => {
        setContent((prev: any) => {
            const newBranches = [...(prev.branches || [])];
            const newId = newBranches.length > 0 ? Math.max(...newBranches.map((b: any) => b.id || 0)) + 1 : 1;
            newBranches.push({
                id: newId,
                name: "New Branch",
                city: "City",
                address: "",
                timings: "Mon-Sat: 8:00 AM - 8:00 PM",
                mapUrl: "",
                facilities: [],
                image: "https://images.unsplash.com/photo-1497366216548-37526070297c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=600"
            });
            return { ...prev, branches: newBranches };
        });
        setExpandedBranch(content?.branches?.length + 1 || 1); // Expand the new one
    };

    const removeBranch = (index: number) => {
        setContent((prev: any) => {
            const newBranches = prev.branches.filter((_: any, i: number) => i !== index);
            return { ...prev, branches: newBranches };
        });
    };

    const handleBatchSubmit = async () => {
        // Validation
        if (!batchFormData.category || !batchFormData.level || !batchFormData.mode || !batchFormData.startDate || !batchFormData.dayTiming || !batchFormData.examAttempt) {
            toast.error("Please fill all required fields");
            return;
        }

        if (batchFormData.mode === "Face to Face" && !batchFormData.location) {
            toast.error("Location is required for Face to Face mode");
            return;
        }

        try {
            setIsAddingBatch(true);
            const { ok, data } = await batchApi.addBatch(batchFormData);
            if (ok && data.success) {
                toast.success("Batch added successfully");
                setBatches([...batches, data.data]);
                setBatchFormData({
                    location: "",
                    category: "",
                    level: "",
                    mode: "",
                    startDate: "",
                    dayTiming: "",
                    examAttempt: ""
                });
            } else {
                toast.error(data.error || "Failed to add batch");
            }
        } catch (error) {
            toast.error("Error connecting to server");
        } finally {
            setIsAddingBatch(false);
        }
    };

    const handleDeleteBatch = async (id: string) => {
        if (!confirm("Are you sure you want to delete this batch?")) return;
        try {
            const { ok, data } = await batchApi.deleteBatch(id);
            if (ok && data.success) {
                toast.success("Batch deleted");
                setBatches(batches.filter(b => b._id !== id));
            } else {
                toast.error("Failed to delete batch");
            }
        } catch (error) {
            toast.error("Error connecting to server");
        }
    };

    if (loading) {
        return <div className="flex justify-center items-center h-96"><Loader2 className="animate-spin h-8 w-8 text-primary" /></div>;
    }

    if (!content) return null;

    return (
        <div className="space-y-6 pb-20">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold tracking-tight">Branch Management</h2>
                    <p className="text-muted-foreground">Manage branch page content and locations.</p>
                </div>
                <Button onClick={handleSave} disabled={saving}>
                    {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    <Save className="mr-2 h-4 w-4" />
                    Save Changes
                </Button>
            </div>

            <Tabs defaultValue="content" className="w-full">
                <TabsList className="grid w-full grid-cols-3 lg:w-[600px]">
                    <TabsTrigger value="content" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">Page Content</TabsTrigger>
                    <TabsTrigger value="locations" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">Locations</TabsTrigger>
                    <TabsTrigger value="batches" className="data-[state=active]:bg-red-600 data-[state=active]:text-white">Batch Management</TabsTrigger>
                </TabsList>

                <TabsContent value="content" className="space-y-6 mt-6">
                    {/* Header Section */}
                    <Card>
                        <CardHeader className="flex flex-row items-center gap-2">
                            <Type className="h-5 w-5 text-primary" />
                            <CardTitle>Header Section</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label>Badge Text</Label>
                                <Input
                                    value={content.branchPage?.header?.badge}
                                    onChange={(e) => updateField('branchPage.header.badge', e.target.value)}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Main Title</Label>
                                <Input
                                    value={content.branchPage?.header?.title}
                                    onChange={(e) => updateField('branchPage.header.title', e.target.value)}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Description</Label>
                                <Textarea
                                    value={content.branchPage?.header?.description}
                                    onChange={(e) => updateField('branchPage.header.description', e.target.value)}
                                />
                            </div>
                        </CardContent>
                    </Card>

                    {/* Stats Section */}
                    <Card>
                        <CardHeader className="flex flex-row items-center gap-2">
                            <Layout className="h-5 w-5 text-primary" />
                            <CardTitle>Display Stats</CardTitle>
                        </CardHeader>
                        <CardContent className="grid grid-cols-2 gap-4">
                            {content.branchPage?.stats?.map((stat: any, idx: number) => (
                                <div key={idx} className="space-y-2 p-3 border rounded bg-muted/20">
                                    <div className="space-y-1">
                                        <Label className="text-xs">Value</Label>
                                        <Input
                                            value={stat.value}
                                            onChange={(e) => updateField(`branchPage.stats.${idx}.value`, e.target.value)}
                                            className="h-8"
                                        />
                                    </div>
                                    <div className="space-y-1">
                                        <Label className="text-xs">Label</Label>
                                        <Input
                                            value={stat.label}
                                            onChange={(e) => updateField(`branchPage.stats.${idx}.label`, e.target.value)}
                                            className="h-8"
                                        />
                                    </div>
                                </div>
                            ))}
                        </CardContent>
                    </Card>

                    {/* CTA Section */}
                    <Card>
                        <CardHeader className="flex flex-row items-center gap-2">
                            <Layout className="h-5 w-5 text-primary" />
                            <CardTitle>Bottom CTA</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label>Title</Label>
                                <Input
                                    value={content.branchPage?.cta?.title}
                                    onChange={(e) => updateField('branchPage.cta.title', e.target.value)}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Description</Label>
                                <Textarea
                                    value={content.branchPage?.cta?.description}
                                    onChange={(e) => updateField('branchPage.cta.description', e.target.value)}
                                />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>Schedule Button</Label>
                                    <Input
                                        value={content.branchPage?.cta?.scheduleBtn}
                                        onChange={(e) => updateField('branchPage.cta.scheduleBtn', e.target.value)}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Download Button</Label>
                                    <Input
                                        value={content.branchPage?.cta?.downloadBtn}
                                        onChange={(e) => updateField('branchPage.cta.downloadBtn', e.target.value)}
                                    />
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="locations" className="space-y-6 mt-6">
                    <div className="flex justify-end mb-4">
                        <Button onClick={addBranch} variant="outline">
                            <Plus className="mr-2 h-4 w-4" />
                            Add Branch
                        </Button>
                    </div>

                    <div className="grid gap-6">
                        {content.branches?.map((branch: any, index: number) => (
                            <Card key={index} className="overflow-hidden">
                                <CardHeader className="bg-muted/10 flex flex-row items-center justify-between p-4 cursor-pointer" onClick={() => setExpandedBranch(expandedBranch === branch.id ? null : branch.id)}>
                                    <div className="flex items-center gap-3">
                                        <MapPin className="h-5 w-5 text-primary" />
                                        <div>
                                            <CardTitle className="text-base">{branch.name || "New Branch"}</CardTitle>
                                            <p className="text-xs text-muted-foreground">{branch.city} - {branch.state}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={(e) => { e.stopPropagation(); setExpandedBranch(expandedBranch === branch.id ? null : branch.id); }}>
                                            <Edit className="h-4 w-4" />
                                        </Button>
                                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-destructive hover:text-destructive" onClick={(e) => { e.stopPropagation(); removeBranch(index); }}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </CardHeader>

                                {expandedBranch === branch.id && (
                                    <CardContent className="p-4 space-y-4 border-t">
                                        {/* Branch Fields */}
                                        <div className="grid md:grid-cols-2 gap-4">
                                            <div className="space-y-2">
                                                <Label>Branch Name</Label>
                                                <Input
                                                    value={branch.name}
                                                    onChange={(e) => updateBranchField(index, 'name', e.target.value)}
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <Label>City</Label>
                                                <Input
                                                    value={branch.city}
                                                    onChange={(e) => updateBranchField(index, 'city', e.target.value)}
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <Label>State</Label>
                                                <Input
                                                    value={branch.state}
                                                    onChange={(e) => updateBranchField(index, 'state', e.target.value)}
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <Label>Pincode</Label>
                                                <Input
                                                    value={branch.pincode}
                                                    onChange={(e) => updateBranchField(index, 'pincode', e.target.value)}
                                                />
                                            </div>
                                            <div className="space-y-2 md:col-span-2">
                                                <Label>Full Address</Label>
                                                <Input
                                                    value={branch.address}
                                                    onChange={(e) => updateBranchField(index, 'address', e.target.value)}
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <Label>Phone</Label>
                                                <Input
                                                    value={branch.phone}
                                                    onChange={(e) => updateBranchField(index, 'phone', e.target.value)}
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <Label>Email</Label>
                                                <Input
                                                    value={branch.email}
                                                    onChange={(e) => updateBranchField(index, 'email', e.target.value)}
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <Label>Timings</Label>
                                                <Input
                                                    value={branch.timings}
                                                    onChange={(e) => updateBranchField(index, 'timings', e.target.value)}
                                                    placeholder="e.g. Mon-Sat: 8:00 AM - 8:00 PM"
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <Label>Students Count</Label>
                                                <Input
                                                    value={branch.students}
                                                    onChange={(e) => updateBranchField(index, 'students', e.target.value)}
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <ImageUpload
                                                    label="Branch Image"
                                                    value={branch.image || ""}
                                                    onChange={(url) => updateBranchField(index, 'image', url)}
                                                />
                                            </div>
                                        </div>

                                        <div className="space-y-2 pt-2 border-t">
                                            <Label className="text-sm font-semibold">Facilities (Comma separated)</Label>
                                            <Input
                                                value={branch.facilities?.join(', ')}
                                                onChange={(e) => updateBranchField(index, 'facilities', e.target.value.split(',').map((s: string) => s.trim()))}
                                                placeholder="e.g. AC Classrooms, Library, Parking"
                                            />
                                        </div>

                                        <div className="space-y-2 pt-2 border-t">
                                            <Label className="text-sm font-semibold">Google Map URL</Label>
                                            <Input
                                                value={branch.mapUrl || ""}
                                                onChange={(e) => updateBranchField(index, 'mapUrl', e.target.value)}
                                                placeholder="https://maps.google.com/..."
                                            />
                                        </div>
                                        <div className="pt-4 mt-2 border-t flex justify-end">
                                            <Button onClick={(e) => { e.stopPropagation(); handleSave(); }} disabled={saving} size="sm">
                                                {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                                <Save className="mr-2 h-4 w-4" />
                                                Save Branch
                                            </Button>
                                        </div>
                                    </CardContent>
                                )}
                            </Card>
                        ))}

                        {(!content.branches || content.branches.length === 0) && (
                            <div className="text-center py-12 border-2 border-dashed rounded-lg">
                                <p className="text-muted-foreground mb-4">No branches found. Add your first branch.</p>
                                <Button onClick={addBranch} variant="outline">
                                    <Plus className="mr-2 h-4 w-4" />
                                    Add Branch
                                </Button>
                            </div>
                        )}
                    </div>
                </TabsContent>
                <TabsContent value="batches" className="space-y-6 mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Add New Batch</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                                <div className="space-y-2">
                                    <Label>Mode</Label>
                                    <Select
                                        value={batchFormData.mode}
                                        onValueChange={(v) => setBatchFormData({ ...batchFormData, mode: v, location: v !== "Face to Face" ? "" : batchFormData.location })}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select Mode" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="Face to Face">Face to Face</SelectItem>
                                            <SelectItem value="Live Online">Live Online</SelectItem>
                                            <SelectItem value="Recorded">Recorded</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label>Location {batchFormData.mode === "Face to Face" && <span className="text-red-500">*</span>}</Label>
                                    <Select
                                        value={batchFormData.location}
                                        onValueChange={(v) => setBatchFormData({ ...batchFormData, location: v })}
                                        disabled={batchFormData.mode !== "Face to Face"}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select Location" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {content.branches?.map((b: any) => (
                                                <SelectItem key={b.id} value={b.name}>{b.name}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label>Course Category</Label>
                                    <Select
                                        value={batchFormData.category}
                                        onValueChange={(v) => setBatchFormData({ ...batchFormData, category: v })}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select Category" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {categories.map((c: any) => (
                                                <SelectItem key={c._id} value={c.name}>{c.name}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label>Level</Label>
                                    <Select
                                        value={batchFormData.level}
                                        onValueChange={(v) => setBatchFormData({ ...batchFormData, level: v })}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select Level" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {levels.map((l: any) => (
                                                <SelectItem key={l._id} value={l.name}>{l.name}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label>Start Date</Label>
                                    <Input
                                        placeholder="e.g. June 15th, 2024"
                                        value={batchFormData.startDate}
                                        onChange={(e) => setBatchFormData({ ...batchFormData, startDate: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Day & Timing</Label>
                                    <Input
                                        placeholder="e.g. Mon to Sat - 7 AM to 1 PM"
                                        value={batchFormData.dayTiming}
                                        onChange={(e) => setBatchFormData({ ...batchFormData, dayTiming: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Exam Attempt</Label>
                                    <Input
                                        placeholder="e.g. May / Nov 2025"
                                        value={batchFormData.examAttempt}
                                        onChange={(e) => setBatchFormData({ ...batchFormData, examAttempt: e.target.value })}
                                    />
                                </div>
                                <div className="flex items-bottom items-end">
                                    <Button onClick={handleBatchSubmit} disabled={isAddingBatch} className="w-full">
                                        {isAddingBatch ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Plus className="mr-2 h-4 w-4" />}
                                        Add Batch
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>Existing Batches</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="rounded-md border">
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Start Date</TableHead>
                                            <TableHead>Day & Timing</TableHead>
                                            <TableHead>Mode</TableHead>
                                            <TableHead>Exam Attempt</TableHead>
                                            <TableHead className="text-right">Action</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {batches.length > 0 ? (
                                            batches.map((batch) => (
                                                <TableRow key={batch._id}>
                                                    <TableCell className="font-medium">{batch.startDate}</TableCell>
                                                    <TableCell>{batch.dayTiming}</TableCell>
                                                    <TableCell>
                                                        <div className="flex items-center gap-2">
                                                            {batch.mode === "Face to Face" ? <GraduationCap className="h-4 w-4" /> :
                                                                batch.mode === "Live Online" ? <Laptop className="h-4 w-4" /> : <Video className="h-4 w-4" />}
                                                            {batch.mode}
                                                            {batch.location && <span className="text-xs text-muted-foreground">({batch.location})</span>}
                                                        </div>
                                                    </TableCell>
                                                    <TableCell>{batch.examAttempt}</TableCell>
                                                    <TableCell className="text-right">
                                                        <Button
                                                            variant="ghost"
                                                            size="sm"
                                                            className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                                                            onClick={() => handleDeleteBatch(batch._id)}
                                                        >
                                                            <Trash className="h-4 w-4" />
                                                        </Button>
                                                    </TableCell>
                                                </TableRow>
                                            ))
                                        ) : (
                                            <TableRow>
                                                <TableCell colSpan={5} className="text-center py-10 text-muted-foreground">No batches found.</TableCell>
                                            </TableRow>
                                        )}
                                    </TableBody>
                                </Table>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}
