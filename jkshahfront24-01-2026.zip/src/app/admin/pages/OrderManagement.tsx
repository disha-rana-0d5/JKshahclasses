import { useState } from "react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../components/ui/table";
import { Badge } from "../../components/ui/badge";
import { Search, Eye, Filter } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../../components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuLabel, DropdownMenuRadioGroup, DropdownMenuRadioItem, DropdownMenuSeparator, DropdownMenuTrigger } from "../../components/ui/dropdown-menu";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "../../components/ui/popover";
import { Label } from "../../components/ui/label";

interface Order {
    id: string;
    user: string;
    course: string;
    amount: string;
    date: string;
    status: "Completed" | "Pending" | "Failed";
    paymentMethod: string;
}

const INITIAL_ORDERS: Order[] = [
    { id: "ORD-1001", user: "Rahul Sharma", course: "CA Foundation Complete", amount: "₹25,000", date: "2024-01-15", status: "Completed", paymentMethod: "UPI" },
    { id: "ORD-1002", user: "Priya Patel", course: "CS Executive Program", amount: "₹38,000", date: "2024-01-14", status: "Pending", paymentMethod: "Net Banking" },
    { id: "ORD-1003", user: "Sneha Gupta", course: "CMA Inter Group 1", amount: "₹22,000", date: "2024-01-12", status: "Completed", paymentMethod: "Credit Card" },
    { id: "ORD-1004", user: "Amit Singh", course: "CA Final Group 2", amount: "₹20,000", date: "2024-01-10", status: "Failed", paymentMethod: "UPI" },
    { id: "ORD-1005", user: "Vikram Malhotra", course: "CA Inter Both Groups", amount: "₹45,000", date: "2024-01-08", status: "Pending", paymentMethod: "Net Banking" },
];

export function OrderManagement() {
    const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
    const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
    const [searchQuery, setSearchQuery] = useState("");
    const [statusFilter, setStatusFilter] = useState("All");
    const [paymentFilter, setPaymentFilter] = useState("All");
    const [startDate, setStartDate] = useState("");
    const [endDate, setEndDate] = useState("");

    const getStatusColor = (status: Order["status"]) => {
        switch (status) {
            case "Completed": return "default";
            case "Pending": return "secondary";
            case "Failed": return "destructive";
            default: return "default";
        }
    };

    const filteredOrders = orders.filter(order => {
        const matchesSearch =
            order.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
            order.id.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesStatus = statusFilter === "All" || order.status === statusFilter;
        const matchesPayment = paymentFilter === "All" || order.paymentMethod === paymentFilter;

        let matchesDate = true;
        if (startDate || endDate) {
            const orderDate = new Date(order.date).getTime();
            const start = startDate ? new Date(startDate).getTime() : 0;
            const end = endDate ? new Date(endDate).getTime() : Infinity;
            matchesDate = orderDate >= start && orderDate <= end;
        }

        return matchesSearch && matchesStatus && matchesPayment && matchesDate;
    });

    const resetFilters = () => {
        setStatusFilter("All");
        setPaymentFilter("All");
        setStartDate("");
        setEndDate("");
    };

    const totalOrders = orders.length;
    const pendingPayments = orders.filter(o => o.status === "Pending").length;
    const totalRevenue = orders
        .filter(o => o.status === "Completed")
        .reduce((acc, curr) => acc + parseInt(curr.amount.replace(/[^0-9]/g, '')), 0)
        .toLocaleString('en-IN', { style: 'currency', currency: 'INR' }).split('.')[0];

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold tracking-tight text-foreground">Order & Payment Management</h2>
                    <p className="text-muted-foreground">Track and manage student purchases.</p>
                </div>
            </div>

            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{totalOrders}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Pending Payments</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold text-orange-600">{pendingPayments}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold text-green-600">{totalRevenue}</div>
                    </CardContent>
                </Card>
            </div>

            <div className="flex flex-col md:flex-row items-end md:items-center justify-between gap-4 mb-4">
                <div className="relative flex-1 w-full md:max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                        placeholder="Search orders..."
                        className="pl-9"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>

                <Popover>
                    <PopoverTrigger asChild>
                        <Button variant="outline" className="gap-2">
                            <Filter className="h-4 w-4" />
                            Filters
                            {(statusFilter !== "All" || paymentFilter !== "All" || startDate || endDate) && (
                                <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-[10px]">Active</Badge>
                            )}
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-96" align="end">
                        <div className="space-y-4">
                            <div className="flex items-center justify-between">
                                <h4 className="font-medium leading-none">Filter Orders</h4>
                                <Button variant="ghost" size="sm" onClick={resetFilters} className="h-auto p-0 text-xs text-muted-foreground hover:text-primary">
                                    Reset
                                </Button>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="status">Status</Label>
                                <Select value={statusFilter} onValueChange={setStatusFilter}>
                                    <SelectTrigger id="status">
                                        <SelectValue placeholder="Select Status" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="All">All Status</SelectItem>
                                        <SelectItem value="Completed">Completed</SelectItem>
                                        <SelectItem value="Pending">Pending</SelectItem>
                                        <SelectItem value="Failed">Failed</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="payment">Payment Method</Label>
                                <Select value={paymentFilter} onValueChange={setPaymentFilter}>
                                    <SelectTrigger id="payment">
                                        <SelectValue placeholder="Select Method" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="All">All Methods</SelectItem>
                                        <SelectItem value="UPI">UPI</SelectItem>
                                        <SelectItem value="Net Banking">Net Banking</SelectItem>
                                        <SelectItem value="Credit Card">Credit Card</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label>Date Range</Label>
                                <div className="flex items-center gap-2">
                                    <Input
                                        type="date"
                                        value={startDate}
                                        onChange={(e) => setStartDate(e.target.value)}
                                        className="h-8 flex-1 text-xs"
                                    />
                                    <span className="text-muted-foreground">-</span>
                                    <Input
                                        type="date"
                                        value={endDate}
                                        onChange={(e) => setEndDate(e.target.value)}
                                        className="h-8 flex-1 text-xs"
                                    />
                                </div>
                            </div>
                        </div>
                    </PopoverContent>
                </Popover>
            </div>

            <div className="rounded-md border border-border bg-white">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Order ID</TableHead>
                            <TableHead>User</TableHead>
                            <TableHead>Course</TableHead>
                            <TableHead>Amount</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Method</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {filteredOrders.length > 0 ? (
                            filteredOrders.map((order) => (
                                <TableRow key={order.id}>
                                    <TableCell className="font-medium">{order.id}</TableCell>
                                    <TableCell>{order.user}</TableCell>
                                    <TableCell className="max-w-[200px] truncate">{order.course}</TableCell>
                                    <TableCell>{order.amount}</TableCell>
                                    <TableCell>{order.date}</TableCell>
                                    <TableCell>{order.paymentMethod}</TableCell>
                                    <TableCell>
                                        <Badge variant={getStatusColor(order.status)}>
                                            {order.status}
                                        </Badge>
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <Button variant="ghost" size="icon" onClick={() => setSelectedOrder(order)}>
                                            <Eye className="h-4 w-4" />
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))
                        ) : (
                            <TableRow>
                                <TableCell colSpan={8} className="h-24 text-center">
                                    No orders found.
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>

            <Dialog open={!!selectedOrder} onOpenChange={(open) => !open && setSelectedOrder(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Order Details</DialogTitle>
                        <DialogDescription>
                            Full details for order {selectedOrder?.id}
                        </DialogDescription>
                    </DialogHeader>
                    {selectedOrder && (
                        <div className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <p className="text-sm font-medium text-muted-foreground">User</p>
                                    <p>{selectedOrder.user}</p>
                                </div>
                                <div>
                                    <p className="text-sm font-medium text-muted-foreground">Date</p>
                                    <p>{selectedOrder.date}</p>
                                </div>
                                <div>
                                    <p className="text-sm font-medium text-muted-foreground">Course</p>
                                    <p>{selectedOrder.course}</p>
                                </div>
                                <div>
                                    <p className="text-sm font-medium text-muted-foreground">Amount</p>
                                    <p className="font-bold text-primary">{selectedOrder.amount}</p>
                                </div>
                                <div>
                                    <p className="text-sm font-medium text-muted-foreground">Status</p>
                                    <Badge variant={getStatusColor(selectedOrder.status)}>{selectedOrder.status}</Badge>
                                </div>
                                <div>
                                    <p className="text-sm font-medium text-muted-foreground">Payment Method</p>
                                    <p>{selectedOrder.paymentMethod}</p>
                                </div>
                            </div>

                            {selectedOrder.status === "Pending" && (
                                <div className="flex gap-2 pt-4">
                                    <Button className="flex-1">Approve</Button>
                                    <Button variant="destructive" className="flex-1">Reject</Button>
                                </div>
                            )}
                        </div>
                    )}
                </DialogContent>
            </Dialog>
        </div>
    );
}
