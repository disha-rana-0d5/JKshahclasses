import { useState } from "react";
import { useCourseContext } from "../context/CourseContext";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../components/ui/table";
import { Plus, Search, Trash2, Pencil } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "../../components/ui/dialog";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Category } from "../context/CourseContext";

export function CategoryManagement() {
    const { categories, addCategory, updateCategory, deleteCategory } = useCourseContext();
    const [searchQuery, setSearchQuery] = useState("");
    const [newCategory, setNewCategory] = useState({
        name: "",
        slug: "",
        metaTitle: "",
        metaDescription: "",
        metaKeywords: ""
    });

    const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
    const [editingCategory, setEditingCategory] = useState<Category | null>(null);
    const [editFormData, setEditFormData] = useState<Partial<Category>>({});

    const filteredCategories = categories.filter(cat =>
        !cat.parent && cat.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const handleAddCategory = () => {
        if (newCategory.name.trim()) {
            addCategory(
                newCategory.name.trim(),
                "",
                undefined,
                newCategory.slug.trim(),
                newCategory.metaTitle.trim(),
                newCategory.metaDescription.trim(),
                newCategory.metaKeywords.trim()
            );
            setNewCategory({
                name: "",
                slug: "",
                metaTitle: "",
                metaDescription: "",
                metaKeywords: ""
            });
        }
    };

    const handleEditClick = (cat: Category) => {
        setEditingCategory(cat);
        setEditFormData({
            name: cat.name,
            slug: cat.slug || "",
            metaTitle: cat.metaTitle || "",
            metaDescription: cat.metaDescription || "",
            metaKeywords: cat.metaKeywords || "",
            whyTitle: cat.whyTitle || "Why CA?",
            whyContent: cat.whyContent || "",
            whyJKShahTitle: cat.whyJKShahTitle || "Why JKShah Classes?",
            whyJKShahContent: cat.whyJKShahContent || ""
        });
        setIsEditDialogOpen(true);
    };

    const handleUpdateCategory = async () => {
        if (editingCategory && editFormData.name?.trim()) {
            await updateCategory(editingCategory._id, editFormData);
            setIsEditDialogOpen(false);
            setEditingCategory(null);
        }
    };

    return (
        <div className="space-y-4">
            <div>
                <h2 className="text-2xl font-bold tracking-tight text-foreground">Category Management</h2>
                <p className="text-muted-foreground">Add, Remove and search course categories.</p>
            </div>

            <div className="grid grid-cols-1 gap-4">
                {/* Create Category Form */}
                <div className="p-6 rounded-xl border border-border bg-white shadow-sm space-y-4">
                    <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                        <Plus className="h-4 w-4 text-primary" /> Create Main Category
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="newName">Category Name</Label>
                            <Input
                                id="newName"
                                placeholder="e.g. Indian Course"
                                value={newCategory.name}
                                onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="newSlug">Slug</Label>
                            <Input
                                id="newSlug"
                                placeholder="e.g. indian-course"
                                value={newCategory.slug}
                                onChange={(e) => setNewCategory({ ...newCategory, slug: e.target.value })}
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="newMetaTitle">Meta Title</Label>
                            <Input
                                id="newMetaTitle"
                                placeholder="Meta Title"
                                value={newCategory.metaTitle}
                                onChange={(e) => setNewCategory({ ...newCategory, metaTitle: e.target.value })}
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="newMetaKeywords">Meta Keywords</Label>
                            <Input
                                id="newMetaKeywords"
                                placeholder="keyword1, keyword2"
                                value={newCategory.metaKeywords}
                                onChange={(e) => setNewCategory({ ...newCategory, metaKeywords: e.target.value })}
                            />
                        </div>
                        <div className="md:col-span-2 space-y-2">
                            <Label htmlFor="newMetaDesc">Meta Description</Label>
                            <Textarea
                                id="newMetaDesc"
                                placeholder="Meta Description"
                                rows={2}
                                value={newCategory.metaDescription}
                                onChange={(e) => setNewCategory({ ...newCategory, metaDescription: e.target.value })}
                            />
                        </div>
                    </div>
                    <div className="flex justify-end">
                        <Button onClick={handleAddCategory} className="w-full md:w-auto">Add Category</Button>
                    </div>
                </div>
            </div>

            <div className="relative w-full">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                    placeholder="Search all categories..."
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
            </div>

            <div className="rounded-md border border-border bg-white">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Category Name</TableHead>
                            <TableHead>Slug</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {filteredCategories.map((cat) => (
                            <TableRow key={cat._id}>
                                <TableCell className="font-medium">
                                    {cat.name}
                                </TableCell>
                                <TableCell className="text-muted-foreground text-sm">
                                    {cat.slug || "-"}
                                </TableCell>
                                <TableCell className="text-right">
                                    <div className="flex justify-end gap-2">
                                        <Button
                                            variant="ghost"
                                            size="sm"
                                            onClick={() => handleEditClick(cat)}
                                            className="text-primary hover:bg-primary/10 hover:text-primary"
                                        >
                                            <Pencil className="h-4 w-4" />
                                        </Button>
                                        <Button
                                            variant="ghost"
                                            size="sm"
                                            onClick={() => deleteCategory(cat._id, cat.name)}
                                            className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                                        >
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                        {filteredCategories.length === 0 && (
                            <TableRow>
                                <TableCell colSpan={3} className="text-center py-10 text-muted-foreground">
                                    No categories found.
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>

            {/* Edit Category Dialog */}
            <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle>Edit Category</DialogTitle>
                        <DialogDescription>
                            Update category details and Comparison section content.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-6 py-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="grid gap-2">
                                <Label htmlFor="name">Category Name</Label>
                                <Input
                                    id="name"
                                    value={editFormData.name || ""}
                                    onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                                />
                            </div>
                            <div className="grid gap-2">
                                <Label htmlFor="slug">Slug</Label>
                                <Input
                                    id="slug"
                                    value={editFormData.slug || ""}
                                    onChange={(e) => setEditFormData({ ...editFormData, slug: e.target.value })}
                                />
                            </div>
                            <div className="grid gap-2">
                                <Label htmlFor="metaTitle">Meta Title</Label>
                                <Input
                                    id="metaTitle"
                                    value={editFormData.metaTitle || ""}
                                    onChange={(e) => setEditFormData({ ...editFormData, metaTitle: e.target.value })}
                                />
                            </div>
                            <div className="grid gap-2">
                                <Label htmlFor="metaKeywords">Meta Keywords</Label>
                                <Input
                                    id="metaKeywords"
                                    value={editFormData.metaKeywords || ""}
                                    onChange={(e) => setEditFormData({ ...editFormData, metaKeywords: e.target.value })}
                                />
                            </div>
                            <div className="md:col-span-2 grid gap-2">
                                <Label htmlFor="metaDescription">Meta Description</Label>
                                <Textarea
                                    id="metaDescription"
                                    rows={2}
                                    value={editFormData.metaDescription || ""}
                                    onChange={(e) => setEditFormData({ ...editFormData, metaDescription: e.target.value })}
                                />
                            </div>
                        </div>

                        <div className="border-t pt-4">
                            <h4 className="text-sm font-semibold mb-4">Comparison Section (Left Side)</h4>
                            <div className="grid gap-4">
                                <div className="grid gap-2">
                                    <Label htmlFor="whyTitle">Title</Label>
                                    <Input
                                        id="whyTitle"
                                        placeholder="e.g. Why CA?"
                                        value={editFormData.whyTitle || ""}
                                        onChange={(e) => setEditFormData({ ...editFormData, whyTitle: e.target.value })}
                                    />
                                </div>
                                <div className="grid gap-2">
                                    <Label htmlFor="whyContent">Content</Label>
                                    <Textarea
                                        id="whyContent"
                                        rows={4}
                                        placeholder="Enter the 'Why' content..."
                                        value={editFormData.whyContent || ""}
                                        onChange={(e) => setEditFormData({ ...editFormData, whyContent: e.target.value })}
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="border-t pt-4">
                            <h4 className="text-sm font-semibold mb-4">Comparison Section (Right Side)</h4>
                            <div className="grid gap-4">
                                <div className="grid gap-2">
                                    <Label htmlFor="whyJKShahTitle">Title</Label>
                                    <Input
                                        id="whyJKShahTitle"
                                        placeholder="e.g. Why JKShah Classes?"
                                        value={editFormData.whyJKShahTitle || ""}
                                        onChange={(e) => setEditFormData({ ...editFormData, whyJKShahTitle: e.target.value })}
                                    />
                                </div>
                                <div className="grid gap-2">
                                    <Label htmlFor="whyJKShahContent">Content</Label>
                                    <Textarea
                                        id="whyJKShahContent"
                                        rows={4}
                                        placeholder="Enter the 'Why JKShah' content..."
                                        value={editFormData.whyJKShahContent || ""}
                                        onChange={(e) => setEditFormData({ ...editFormData, whyJKShahContent: e.target.value })}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>Cancel</Button>
                        <Button onClick={handleUpdateCategory}>Save Changes</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
