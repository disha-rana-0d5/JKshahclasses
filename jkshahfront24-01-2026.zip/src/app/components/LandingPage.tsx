import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Link, useNavigate } from "react-router-dom";
import { BookOpen, GraduationCap, TrendingUp, Users, Award, Star, Play, ArrowRight, CheckCircle2, Trophy, Clock, Target, Zap, Shield, Calendar, MapPin, Video, FileText, Headphones } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { BookDemoModal } from "./modals/BookDemoModal";
import { EnrollModal } from "./modals/EnrollModal";
import { VideoModal } from "./modals/VideoModal";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "./ui/carousel";
import { useCourseContext } from "../admin/context/CourseContext";
import { facultyApi, landingPageApi } from "../api/api";

export function LandingPage() {
    const navigate = useNavigate();
    const { courses } = useCourseContext();
    const [showDemoModal, setShowDemoModal] = useState(false);
    const [showEnrollModal, setShowEnrollModal] = useState(false);
    const [showVideoModal, setShowVideoModal] = useState(false);
    const [selectedCourse, setSelectedCourse] = useState<{ name: string; price: string } | null>(null);
    const [activeFilter, setActiveFilter] = useState("All");
    const [content, setContent] = useState<any>(null);
    const [faculties, setFaculties] = useState<any[]>([]);

    // Calculate trending courses and derived categories
    const trendingCourses = courses.filter(c => c.status === "Active").slice(0, 3);
    const visibleCategories = Array.from(new Set(trendingCourses.map(c => c.category)));

    useEffect(() => {
        document.title = "JK Shah Classes - India's Leading CA Coaching";
    }, []);

    useEffect(() => {
        const loadPageData = async () => {
            try {
                const [contentRes, facultyRes] = await Promise.all([
                    landingPageApi.getLandingContent(),
                    facultyApi.getFaculties()
                ]);

                if (contentRes.ok && contentRes.data.success) {
                    setContent(contentRes.data.data);
                }
                if (facultyRes.ok && facultyRes.data.success) {
                    setFaculties(facultyRes.data.data);
                }
            } catch (error) {
                console.error("Failed to load landing data", error);
            }
        };
        loadPageData();
    }, []);

    if (!content) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

    return (
        <div className="flex flex-col min-h-screen">
            <main>
                {/* Hero Section - Asymmetric Split Design */}
                <section className="pt-24 pb-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-primary/5 via-white to-accent/5">
                    <div className="max-w-7xl mx-auto">
                        <div className="grid lg:grid-cols-12 gap-6 items-start">
                            {/* Left Content - 7 columns */}
                            <div className="lg:col-span-7">
                                <div className="inline-flex items-center gap-2 bg-accent text-white px-3 py-1.5 rounded-full text-sm mb-3">
                                    <Trophy className="w-3.5 h-3.5" />
                                    <span>{content.hero.badge}</span>
                                </div>

                                <h1 className="text-4xl lg:text-5xl mb-3 text-foreground leading-tight">
                                    {content.hero.title}
                                </h1>

                                <p className="text-base text-muted-foreground mb-4 leading-relaxed">
                                    {content.hero.description}
                                </p>

                                {/* Quick Action Grid */}
                                <div className="grid grid-cols-2 gap-3 mb-4">
                                    <Button
                                        onClick={() => setShowVideoModal(true)}
                                        className="bg-primary hover:bg-primary/90 text-white h-auto py-3"
                                    >
                                        <Play className="w-4 h-4 mr-2" />
                                        {content.hero.ctaDemoText}
                                    </Button>
                                    <Button
                                        variant="outline"
                                        className="border-2 border-primary text-primary hover:bg-primary/5 hover:!text-primary h-auto py-3"
                                        onClick={() => navigate("/courses")}
                                    >
                                        {content.hero.ctaCoursesText}
                                    </Button>
                                </div>

                                {/* Inline Stats */}
                                <div className="grid grid-cols-3 gap-3 p-4 bg-white rounded-lg border border-border">
                                    {content.hero.stats?.map((stat: any, idx: number) => (
                                        <div key={idx} className="text-center border-r border-border last:border-0">
                                            <p className="text-2xl text-primary mb-0.5">{stat.value}</p>
                                            <p className="text-xs text-muted-foreground">{stat.label}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Right Sidebar - 5 columns */}
                            <div className="lg:col-span-5 space-y-4">
                                {/* Hero Image */}
                                <div className="relative rounded-lg overflow-hidden shadow-lg h-64">
                                    <ImageWithFallback
                                        src={content.hero.image}
                                        alt="Students learning"
                                        className="w-full h-full object-cover"
                                    />
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                                    <div className="absolute bottom-4 left-4 right-4">
                                        <div className="flex items-center gap-2 text-white">
                                            <Video className="w-5 h-5" />
                                            <span className="text-sm">Live & Recorded Classes Available</span>
                                        </div>
                                    </div>
                                </div>

                                {/* Quick Info Cards */}
                                <div className="grid grid-cols-2 gap-3">
                                    {content.hero.quickInfo?.map((info: any, idx: number) => {
                                        const Icon = idx === 0 ? Target : Users;
                                        const colorClass = idx === 0 ? "text-primary" : "text-accent";

                                        return (
                                            <div key={idx} className="bg-white border border-border rounded-lg p-3">
                                                <Icon className={`w-5 h-5 ${colorClass} mb-2`} />
                                                <p className="text-xs text-muted-foreground mb-0.5">{info.label}</p>
                                                <p className="text-sm text-foreground">{info.value}</p>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                {/* Course Categories - Compact Grid */}
                {/* <section className="py-8 px-4 sm:px-6 lg:px-8 bg-muted/30">
                    <div className="max-w-7xl mx-auto">
                        <div className="flex items-center justify-between mb-4">
                            <div>
                                <h2 className="text-2xl text-foreground mb-1">{content.popularPrograms?.title}</h2>
                                <p className="text-sm text-muted-foreground">{content.popularPrograms?.subtitle}</p>
                            </div>
                            <Button
                                variant="ghost"
                                className="text-primary"
                                onClick={() => navigate("/courses")}
                            >
                                View All →
                            </Button>
                        </div>

                        <div className="grid md:grid-cols-6 gap-3">
                            {[
                                { title: "CA Foundation", icon: BookOpen, count: "8 Courses", color: "primary" },
                                { title: "CA Inter", icon: GraduationCap, count: "6 Courses", color: "accent" },
                                { title: "CA Final", icon: Award, count: "5 Courses", color: "primary" },
                                { title: "CS Executive", icon: Shield, count: "4 Courses", color: "accent" },
                                { title: "CS Professional", icon: TrendingUp, count: "5 Courses", color: "primary" },
                                { title: "CMA", icon: Target, count: "6 Courses", color: "accent" }
                            ].map((category, idx) => (
                                <div key={idx}
                                    className="bg-white rounded-lg p-4 shadow-sm hover:shadow-md transition-all group cursor-pointer border border-transparent hover:border-primary"
                                    onClick={() => navigate(`/courses/category/${encodeURIComponent(category.title)}`)}
                                >
                                    <div className={`bg-${category.color}/10 rounded p-2 w-fit mb-2`}>
                                        <category.icon className={`w-5 h-5 text-${category.color}`} />
                                    </div>
                                    <h3 className="text-sm mb-1 text-foreground">{category.title}</h3>
                                    <p className="text-xs text-muted-foreground">{category.count}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </section> */}

                {/* Featured Courses - Dense Card Layout */}
                <section className="py-8 px-4 sm:px-6 lg:px-8">
                    <div className="max-w-7xl mx-auto">
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="text-2xl text-foreground">Trending Courses</h2>
                            <div className="flex gap-2 flex-wrap justify-end">
                                <Button
                                    size="sm"
                                    variant={activeFilter === "All" ? "default" : "ghost"}
                                    className="text-xs"
                                    onClick={() => setActiveFilter("All")}
                                >
                                    All
                                </Button>
                                {visibleCategories.map((category) => (
                                    <Button
                                        key={category}
                                        size="sm"
                                        variant={activeFilter === category ? "default" : "ghost"}
                                        className="text-xs"
                                        onClick={() => setActiveFilter(category)}
                                    >
                                        {category}
                                    </Button>
                                ))}
                            </div>
                        </div>

                        <div className="grid lg:grid-cols-3 gap-4">
                            {trendingCourses
                                .filter(c => activeFilter === "All" || c.category === activeFilter)
                                .map((course) => (
                                    <div
                                        key={course._id}
                                        className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-lg transition-all group border border-border cursor-pointer flex flex-col"
                                        onClick={() => navigate(`/course/${course.title.toLowerCase().replace(/ /g, '-')}`)}
                                    >
                                        <div
                                            className="relative h-40 overflow-hidden"
                                        >
                                            <ImageWithFallback
                                                src={course.image}
                                                alt={course.title}
                                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                            />
                                            <div className="absolute top-2 left-2 flex gap-2">
                                                <span
                                                    className="bg-white/95 backdrop-blur-sm text-foreground px-2 py-0.5 rounded text-[10px] uppercase font-bold hover:bg-white cursor-pointer transition-colors"
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        navigate(`/courses/category/${encodeURIComponent(course.category)}`);
                                                    }}
                                                >
                                                    {course.category}
                                                </span>
                                                {course.batchInfo && (
                                                    <span className="bg-accent text-white px-2 py-0.5 rounded text-[10px] uppercase font-bold">
                                                        {course.batchInfo}
                                                    </span>
                                                )}
                                                {course.discount && (
                                                    <span className="bg-primary text-white px-2 py-0.5 rounded text-[10px] uppercase font-bold">
                                                        {course.discount}
                                                    </span>
                                                )}
                                            </div>
                                            <div className="absolute top-2 right-2 flex items-center gap-1 bg-white/95 backdrop-blur-sm px-2 py-0.5 rounded shadow-sm">
                                                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                                <span className="text-xs font-bold text-foreground">{course.rating}</span>
                                                <span className="text-[10px] text-muted-foreground">({course.reviews})</span>
                                            </div>
                                        </div>

                                        <div className="p-4 flex flex-col flex-1">
                                            <div className="mb-3">
                                                <h3 className="text-base font-semibold mb-1 text-foreground line-clamp-1 group-hover:text-primary transition-colors">{course.title}</h3>
                                                <div className="flex items-center gap-2 mb-2 text-xs text-muted-foreground">
                                                    <span className="flex items-center gap-1">
                                                        <Clock className="w-3 h-3" />
                                                        {course.duration}
                                                    </span>
                                                    <span>•</span>
                                                    <span className="flex items-center gap-1">
                                                        <Video className="w-3 h-3" />
                                                        {course.lessons} Lessons
                                                    </span>
                                                </div>
                                            </div>

                                            <div className="flex items-center gap-3 mb-4">
                                                <img src={course.facultyImage} className="w-8 h-8 rounded-full border border-border" />
                                                <div className="flex flex-col">
                                                    <p className="text-xs font-medium text-foreground">{course.facultyName}</p>
                                                    <p className="text-[10px] text-muted-foreground">{course.enrolledTotal}+ enrolled students</p>
                                                </div>
                                            </div>

                                            <div className="mt-auto flex items-center justify-between pt-3 border-t border-border">
                                                <div className="flex flex-col">
                                                    <span className="text-lg font-bold text-red-600 leading-none">₹{course.price}</span>
                                                    {course.originalPrice && (
                                                        <span className="text-xs text-muted-foreground line-through">₹{course.originalPrice}</span>
                                                    )}
                                                </div>
                                                <Button
                                                    size="sm"
                                                    className="bg-primary hover:bg-primary/90 text-white h-8 text-xs px-4"
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        setSelectedCourse({ name: course.title, price: `₹${course.price}` });
                                                        setShowEnrollModal(true);
                                                    }}
                                                >
                                                    Enroll
                                                </Button>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            {courses.filter(c => c.status === "Active").length === 0 && (
                                <div className="col-span-3 py-12 text-center bg-muted/20 rounded-lg border border-dashed border-border">
                                    <p className="text-muted-foreground">No trending courses available at the moment.</p>
                                </div>
                            )}
                        </div>
                    </div>
                </section>

                {/* Online Learning Experience Section */}
                <section className="py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-primary/5 via-white to-white">
                    <div className="max-w-7xl mx-auto">
                        <div className="grid lg:grid-cols-2 gap-12 items-center">
                            {/* Left Content */}
                            <div>
                                <div className="inline-flex items-center gap-2 bg-accent/10 border border-accent/20 text-accent px-3 py-1.5 rounded-full text-sm mb-4">
                                    <Zap className="w-3.5 h-3.5" />
                                    <span>{content.onlineExperience.badge}</span>
                                </div>

                                <h2 className="text-3xl lg:text-4xl mb-3 text-foreground">
                                    {content.onlineExperience.title}
                                </h2>

                                <p className="text-base text-muted-foreground mb-6 leading-relaxed">
                                    {content.onlineExperience.description}
                                </p>

                                {/* Feature Grid */}
                                <div className="space-y-4 mb-6">
                                    {[
                                        {
                                            icon: Video,
                                            title: "Live Interactive Classes",
                                            desc: "Real-time teaching with faculty, not pre-recorded generic videos",
                                            color: "primary"
                                        },
                                        {
                                            icon: Clock,
                                            title: "Recorded Lecture Access",
                                            desc: "Revisit any lecture anytime with lifetime access to recordings",
                                            color: "primary"
                                        },
                                        {
                                            icon: Headphones,
                                            title: "Instant Doubt Resolution",
                                            desc: "Live Q&A sessions and dedicated doubt-clearing forums",
                                            color: "accent"
                                        },
                                        {
                                            icon: Calendar,
                                            title: "Structured Batch Schedules",
                                            desc: "Organized timetables designed by experts for optimal learning",
                                            color: "primary"
                                        }
                                    ].map((feature, idx) => (
                                        <div key={idx} className="flex items-start gap-4 group">
                                            <div className={`bg-${feature.color}/10 rounded-lg p-3 flex-shrink-0 group-hover:bg-${feature.color}/20 transition-colors`}>
                                                <feature.icon className={`w-5 h-5 text-${feature.color}`} />
                                            </div>
                                            <div className="flex-1">
                                                <h3 className="text-base text-foreground mb-1">{feature.title}</h3>
                                                <p className="text-sm text-muted-foreground leading-relaxed">{feature.desc}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>

                                <div className="flex flex-col sm:flex-row gap-3">
                                    <Button
                                        className="bg-primary hover:bg-primary/90 text-white"
                                        onClick={() => navigate("/#")}
                                    >
                                        <Video className="w-4 h-4 mr-2" />
                                        Browse Live Sessions
                                    </Button>
                                    <Button
                                        variant="outline"
                                        onClick={() => setShowVideoModal(true)}
                                    >
                                        <Play className="w-4 h-4 mr-2" />
                                        Watch Platform Demo
                                    </Button>
                                </div>
                            </div>

                            {/* Right Image */}
                            <div className="relative">
                                <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                                    <ImageWithFallback
                                        src={content.onlineExperience.image}
                                        alt="Students attending live online class"
                                        className="w-full h-[500px] object-cover"
                                    />
                                    {/* Floating Stats */}
                                    <div className="absolute top-6 left-6 bg-white/95 backdrop-blur-sm rounded-lg shadow-lg p-4">
                                        <div className="flex items-center gap-3">
                                            <div className="bg-accent/10 rounded-full p-2">
                                                <Users className="w-4 h-4 text-accent" />
                                            </div>
                                            <div>
                                                <p className="text-xs text-muted-foreground">Live Now</p>
                                                <p className="text-lg text-foreground">1,234 Students</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="absolute bottom-6 right-6 bg-white/95 backdrop-blur-sm rounded-lg shadow-lg p-4">
                                        <div className="flex items-center gap-3">
                                            <div className="bg-primary/10 rounded-full p-2">
                                                <Star className="w-4 h-4 text-primary fill-primary" />
                                            </div>
                                            <div>
                                                <p className="text-xs text-muted-foreground">Avg. Rating</p>
                                                <p className="text-lg text-foreground">4.9/5.0</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Decorative Elements */}
                                <div className="absolute -top-4 -right-4 w-32 h-32 bg-primary/10 rounded-full blur-3xl -z-10"></div>
                                <div className="absolute -bottom-4 -left-4 w-40 h-40 bg-accent/10 rounded-full blur-3xl -z-10"></div>
                            </div>
                        </div>
                    </div>
                </section>

                {/* Stats + Testimonials Combined Section */}
                <section className="py-8 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-primary/5 to-accent/5">
                    <div className="max-w-7xl mx-auto">
                        <div className="grid lg:grid-cols-12 gap-6">
                            {/* Left Stats */}
                            <div className="lg:col-span-5">
                                <h2 className="text-2xl mb-3 text-foreground">{content.whyChooseUs.title}</h2>
                                <div className="grid grid-cols-2 gap-3 mb-6">
                                    {content.whyChooseUs.statsGrid?.map((stat: any, idx: number) => {
                                        const icons = [Users, TrendingUp, Award, MapPin];
                                        const Icon = icons[idx] || Users;
                                        const color = stat.color || (idx % 2 === 0 ? "primary" : "accent");

                                        return (
                                            <div key={idx} className="bg-white rounded-lg p-4 shadow-sm">
                                                <div className="flex items-center gap-3">
                                                    <div className={`bg-${color}/10 rounded-lg p-2`}>
                                                        <Icon className={`w-5 h-5 text-${color}`} />
                                                    </div>
                                                    <div>
                                                        <p className="text-2xl text-foreground leading-none mb-1">{stat.value}</p>
                                                        <p className="text-xs text-muted-foreground">{stat.label}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        )
                                    })}
                                </div>

                                {/* Feature List */}
                                <div className="bg-white rounded-lg p-4 shadow-sm">
                                    <h3 className="text-base mb-3 text-foreground">{content.whyChooseUs.featuresTitle || "What You Get"}</h3>
                                    <div className="space-y-2">
                                        {content.whyChooseUs.featuresList?.map((feature: string, idx: number) => (
                                            <div key={idx} className="flex items-start gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                                                <span className="text-sm text-foreground">{feature}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            {/* Right Testimonials */}
                            <div className="lg:col-span-7">
                                <h3 className="text-2xl mb-3 text-foreground">{content.testimonials.title}</h3>
                                {content.testimonials?.list?.length > 6 ? (
                                    <div className="px-0 lg:px-12">
                                        <Carousel
                                            opts={{
                                                align: "start",
                                                loop: true,
                                            }}
                                            className="w-full"
                                        >
                                            <CarouselContent>
                                                {Array.from({ length: Math.ceil((content.testimonials?.list?.length || 0) / 6) }).map((_, pageIdx) => (
                                                    <CarouselItem key={pageIdx} className="basis-full">
                                                        <div className="grid grid-cols-2 gap-2 md:grid-cols-2 md:gap-3">
                                                            {(content.testimonials?.list || []).slice(pageIdx * 6, (pageIdx + 1) * 6).map((testimonial: any, idx: number) => (
                                                                <div key={idx} className="bg-white rounded-lg p-3 md:p-4 shadow-sm h-full flex flex-col justify-between">
                                                                    <div>
                                                                        <div className="flex items-start gap-3 mb-2">
                                                                            <ImageWithFallback
                                                                                src={testimonial.image}
                                                                                alt={testimonial.name}
                                                                                className="w-8 h-8 md:w-10 md:h-10 rounded-full object-cover flex-shrink-0"
                                                                            />
                                                                            <div className="flex-1 min-w-0">
                                                                                <p className="text-sm text-foreground mb-0.5">{testimonial.name}</p>
                                                                                <div className="flex items-center gap-1">
                                                                                    <Trophy className="w-3 h-3 text-accent flex-shrink-0" />
                                                                                    <p className="text-xs text-muted-foreground truncate">{testimonial.rank}</p>
                                                                                </div>
                                                                            </div>
                                                                            <div className="hidden sm:flex gap-0.5">
                                                                                {[...Array(5)].map((_, i) => (
                                                                                    <Star key={i} className="w-3 h-3 fill-accent text-accent" />
                                                                                ))}
                                                                            </div>
                                                                        </div>
                                                                        <p className="text-xs md:text-sm text-muted-foreground leading-relaxed line-clamp-4">"{testimonial.text}"</p>
                                                                    </div>
                                                                </div>
                                                            ))}
                                                        </div>
                                                    </CarouselItem>
                                                ))}
                                            </CarouselContent>
                                            <CarouselPrevious className="!hidden lg:flex" />
                                            <CarouselNext className="!hidden lg:flex" />
                                        </Carousel>
                                    </div>
                                ) : (
                                    <div className="grid md:grid-cols-2 gap-3">
                                        {(content.testimonials?.list || []).map((testimonial: any, idx: number) => (
                                            <div key={idx} className="bg-white rounded-lg p-4 shadow-sm h-full">
                                                <div className="flex items-start gap-3 mb-2">
                                                    <ImageWithFallback
                                                        src={testimonial.image}
                                                        alt={testimonial.name}
                                                        className="w-10 h-10 rounded-full object-cover flex-shrink-0"
                                                    />
                                                    <div className="flex-1 min-w-0">
                                                        <p className="text-sm text-foreground mb-0.5">{testimonial.name}</p>
                                                        <div className="flex items-center gap-1">
                                                            <Trophy className="w-3 h-3 text-accent flex-shrink-0" />
                                                            <p className="text-xs text-muted-foreground truncate">{testimonial.rank}</p>
                                                        </div>
                                                    </div>
                                                    <div className="flex gap-0.5">
                                                        {[...Array(5)].map((_, i) => (
                                                            <Star key={i} className="w-3 h-3 fill-accent text-accent" />
                                                        ))}
                                                    </div>
                                                </div>
                                                <p className="text-sm text-muted-foreground leading-relaxed">"{testimonial.text}"</p>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </section>

                {/* Faculty Section - Horizontal Scroll */}
                <section className="py-8 px-4 sm:px-6 lg:px-8">
                    <div className="max-w-7xl mx-auto">
                        <div className="flex items-center justify-between mb-4">
                            <div>
                                <h2 className="text-2xl text-foreground mb-1">{content.facultySection.title}</h2>
                                <p className="text-sm text-muted-foreground">{content.facultySection.subtitle}</p>
                            </div>
                            <Button
                                variant="ghost"
                                className="text-primary"
                                onClick={() => navigate("/faculty")}
                            >
                                View All Faculty →
                            </Button>
                        </div>

                        <div className="grid md:grid-cols-4 gap-4">
                            {(faculties.length > 0 ? faculties.slice(0, 4) : [
                                {
                                    name: "Dr. Rajesh Kumar",
                                    designation: "CA, PhD",
                                    specialization: "Financial Accounting",
                                    experience: "20+",
                                    totalStudents: "5000+",
                                    rating: "4.9",
                                    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
                                },
                                {
                                    name: "Prof. Anjali Mehta",
                                    designation: "CS, MBA",
                                    specialization: "Corporate Law",
                                    experience: "15+",
                                    totalStudents: "4200+",
                                    rating: "4.8",
                                    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
                                },
                                {
                                    name: "Dr. Vikram Singh",
                                    designation: "CA, CFA",
                                    specialization: "Taxation",
                                    experience: "18+",
                                    totalStudents: "4800+",
                                    rating: "4.9",
                                    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
                                },
                                {
                                    name: "Prof. Meera Patel",
                                    designation: "CMA, M.Com",
                                    specialization: "Cost Accounting",
                                    experience: "12+",
                                    totalStudents: "3500+",
                                    rating: "4.8",
                                    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
                                }
                            ]).map((faculty, idx) => (
                                <div key={idx}
                                    className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all border border-border cursor-pointer"
                                    onClick={() => navigate("/faculty", { state: { facultyName: faculty.name } })}
                                >
                                    <div className="relative h-48 overflow-hidden bg-gradient-to-br from-primary/5 to-accent/5">
                                        <ImageWithFallback
                                            src={faculty.image}
                                            alt={faculty.name}
                                            className="w-full h-full object-cover"
                                        />
                                        <div className="absolute top-2 right-2 bg-white/95 backdrop-blur-sm px-2 py-1 rounded flex items-center gap-1">
                                            <Star className="w-3 h-3 fill-accent text-accent" />
                                            <span className="text-xs text-foreground">{faculty.rating}</span>
                                        </div>
                                    </div>
                                    <div className="p-3">
                                        <h3 className="text-sm mb-0.5 text-foreground">{faculty.name}</h3>
                                        <p className="text-xs text-muted-foreground mb-2">{faculty.designation}</p>

                                        <div className="space-y-1.5 text-xs">
                                            <div className="flex justify-between">
                                                <span className="text-muted-foreground">Specialization</span>
                                                <span className="text-foreground">{faculty.specialization}</span>
                                            </div>
                                            <div className="flex justify-between">
                                                <span className="text-muted-foreground">Experience</span>
                                                <span className="text-primary">{faculty.experience}{typeof faculty.experience === 'number' ? 'Y' : ''}</span>
                                            </div>
                                            <div className="flex justify-between">
                                                <span className="text-muted-foreground">Students</span>
                                                <span className="text-accent">{faculty.totalStudents || faculty.students}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* Learning Features - Bento Grid Style */}
                <section className="py-8 px-4 sm:px-6 lg:px-8 bg-muted/30">
                    <div className="max-w-7xl mx-auto">
                        <h2 className="text-2xl mb-4 text-foreground">Complete Learning Ecosystem</h2>

                        <div className="grid md:grid-cols-4 gap-3">
                            {[
                                { icon: Video, title: "Live Classes", desc: "Interactive sessions", color: "primary" },
                                { icon: FileText, title: "Study Material", desc: "Comprehensive notes", color: "accent" },
                                { icon: Headphones, title: "24/7 Support", desc: "Doubt clearing", color: "primary" },
                                { icon: Trophy, title: "Mock Tests", desc: "Regular practice", color: "accent" },
                            ].map((feature, idx) => (
                                <div key={idx} className="bg-white rounded-lg p-4 shadow-sm hover:shadow-md transition-all">
                                    <div className={`bg-${feature.color}/10 rounded-lg p-2 w-fit mb-2`}>
                                        <feature.icon className={`w-5 h-5 text-${feature.color}`} />
                                    </div>
                                    <h3 className="text-sm mb-0.5 text-foreground">{feature.title}</h3>
                                    <p className="text-xs text-muted-foreground">{feature.desc}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* CTA Section - Compact */}
                <section className="py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-primary via-primary/90 to-accent">
                    <div className="max-w-5xl mx-auto">
                        <div className="grid md:grid-cols-2 gap-6 items-center">
                            <div>
                                <h2 className="text-3xl mb-2 text-white">{content.footerCta.title}</h2>
                                <p className="text-base text-white/90">
                                    {content.footerCta.description}
                                </p>
                            </div>
                            <div className="flex flex-col sm:flex-row gap-3">
                                <Button
                                    size="lg"
                                    className="bg-white text-primary hover:bg-white/90 flex-1"
                                    onClick={() => setShowDemoModal(true)}
                                >
                                    {content.footerCta.demoButtonText}
                                    <ArrowRight className="w-4 h-4 ml-2" />
                                </Button>
                                <Button
                                    size="lg"
                                    variant="outline"
                                    className="bg-transparent border-2 border-white text-white hover:bg-white/10 flex-1"
                                    onClick={() => {
                                        if (content.footerCta.brochureUrl) {
                                            window.open(content.footerCta.brochureUrl, '_blank');
                                        } else {
                                            alert("Brochure coming soon!");
                                        }
                                    }}
                                >
                                    {content.footerCta.brochureButtonText}
                                </Button>
                            </div>
                        </div>
                    </div>
                </section>
            </main>

            {/* Modals */}
            <BookDemoModal
                isOpen={showDemoModal}
                onClose={() => setShowDemoModal(false)}
            />
            <EnrollModal
                isOpen={showEnrollModal}
                onClose={() => setShowEnrollModal(false)}
                courseName={selectedCourse?.name}
                coursePrice={selectedCourse?.price}
            />
            <VideoModal
                isOpen={showVideoModal}
                onClose={() => setShowVideoModal(false)}
                videoTitle="JK Shah Classes - Demo Class"
                videoUrl={content.onlineExperience?.videoUrl}
            />
        </div>
    );
}
