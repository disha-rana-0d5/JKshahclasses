import { useEffect } from "react";
import { Button } from "./ui/button";
import { Calendar, Clock, Users, Video, Filter, Search } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function LiveSessionsPage() {
  const liveSessions = [
    {
      courseName: "CA Foundation - Accounts",
      examLevel: "CA Foundation",
      levelTag: "Foundation",
      faculty: {
        name: "Dr. Rajesh Kumar",
        image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
      },
      batchStart: "Jan 15, 2024",
      timing: "Mon-Fri, 7:00 PM - 9:00 PM",
      mode: "Live Online",
      students: 156,
      seats: "24 seats left",
      duration: "6 Months",
      badge: "Starting Soon"
    },
    {
      courseName: "CA Inter - Direct Tax",
      examLevel: "CA Intermediate",
      levelTag: "Intermediate",
      faculty: {
        name: "Dr. Vikram Singh",
        image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
      },
      batchStart: "Jan 20, 2024",
      timing: "Tue-Thu-Sat, 6:00 PM - 8:30 PM",
      mode: "Live Online",
      students: 89,
      seats: "31 seats left",
      duration: "4 Months",
      badge: "Popular"
    },
    {
      courseName: "CS Executive - Corporate Law",
      examLevel: "CS Executive",
      levelTag: "Executive",
      faculty: {
        name: "Prof. Anjali Mehta",
        image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
      },
      batchStart: "Jan 18, 2024",
      timing: "Wed-Fri, 8:00 PM - 10:00 PM",
      mode: "Live Online",
      students: 67,
      seats: "18 seats left",
      duration: "5 Months",
      badge: "Bestseller"
    },
    {
      courseName: "CA Final - Advanced Auditing",
      examLevel: "CA Final",
      levelTag: "Final",
      faculty: {
        name: "CA Pradeep Jain",
        image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
      },
      batchStart: "Jan 22, 2024",
      timing: "Mon-Wed-Fri, 7:30 PM - 10:00 PM",
      mode: "Live Online",
      students: 45,
      seats: "15 seats left",
      duration: "3 Months",
      badge: "Limited Seats"
    },
    {
      courseName: "CMA Inter - Cost Accounting",
      examLevel: "CMA Intermediate",
      levelTag: "Intermediate",
      faculty: {
        name: "Prof. Meera Patel",
        image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
      },
      batchStart: "Jan 25, 2024",
      timing: "Tue-Thu-Sat, 7:00 PM - 9:00 PM",
      mode: "Live Online",
      students: 92,
      seats: "28 seats left",
      duration: "5 Months",
      badge: "New Batch"
    },
    {
      courseName: "CS Professional - Advanced Tax",
      examLevel: "CS Professional",
      levelTag: "Professional",
      faculty: {
        name: "Dr. Sanjay Verma",
        image: "https://images.unsplash.com/photo-1556157382-97eda2d62296?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
      },
      batchStart: "Feb 1, 2024",
      timing: "Mon-Thu, 8:00 PM - 10:00 PM",
      mode: "Live Online",
      students: 54,
      seats: "21 seats left",
      duration: "4 Months",
      badge: "Popular"
    },
    {
      courseName: "CA Foundation - Business Laws",
      examLevel: "CA Foundation",
      levelTag: "Foundation",
      faculty: {
        name: "Prof. Neha Gupta",
        image: "https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400"
      },
      batchStart: "Feb 5, 2024",
      timing: "Wed-Fri-Sun, 6:30 PM - 8:30 PM",
      mode: "Live Online",
      students: 78,
      seats: "32 seats left",
      duration: "3 Months",
      badge: "Starting Soon"
    },
    {
      courseName: "CA Inter - Audit & Assurance",
      examLevel: "CA Intermediate",
      levelTag: "Intermediate",
      faculty: {
        name: "CA Rohit Sharma",
        image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=200"
      },
      batchStart: "Feb 8, 2024",
      timing: "Tue-Thu-Sat, 7:00 PM - 9:30 PM",
      mode: "Live Online",
      students: 103,
      seats: "17 seats left",
      duration: "5 Months",
      badge: "Bestseller"
    },
    {
      courseName: "CMA Final - Strategic Management",
      examLevel: "CMA Final",
      levelTag: "Final",
      faculty: {
        name: "Prof. Arjun Nair",
        image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=200"
      },
      batchStart: "Feb 10, 2024",
      timing: "Mon-Wed-Fri, 8:00 PM - 10:30 PM",
      mode: "Live Online",
      students: 41,
      seats: "9 seats left",
      duration: "4 Months",
      badge: "Limited Seats"
    }
  ];

  useEffect(() => {
    document.title = "Live Sessions | JK Shah Classes";
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Header Section */}
      <section className="pt-24 pb-8 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-primary/5 via-white to-accent/5">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-2 text-accent mb-3">
            <Video className="w-5 h-5" />
            <span className="text-sm">Live Online Batches</span>
          </div>

          <h1 className="text-3xl lg:text-4xl mb-3 text-foreground">
            Upcoming Live Sessions
          </h1>

          <p className="text-base text-muted-foreground mb-6 max-w-3xl">
            Join faculty-led live interactive classes from anywhere. All sessions include recorded lectures, doubt-clearing, and structured study plans.
          </p>

          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search by course or faculty..."
                className="w-full pl-10 pr-4 py-3 border border-border rounded-lg focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-colors"
              />
            </div>

            <div className="flex gap-2">
              <Button variant="outline" className="border border-border">
                <Filter className="w-4 h-4 mr-2" />
                Filters
              </Button>
              <select className="px-4 py-2 border border-border rounded-lg focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-colors bg-white text-sm">
                <option>All Levels</option>
                <option>Foundation</option>
                <option>Intermediate</option>
                <option>Final</option>
                <option>Executive</option>
                <option>Professional</option>
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Sessions Grid */}
      <section className="py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-3 md:grid-cols-2 gap-5">
            {liveSessions.map((session, idx) => (
              <div key={idx} className="bg-white border border-border rounded-lg overflow-hidden hover:shadow-lg transition-all group">
                {/* Header with Badge */}
                <div className="p-4 border-b border-border bg-muted/30">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="text-base text-foreground mb-1 group-hover:text-primary transition-colors">
                        {session.courseName}
                      </h3>
                      <div className="flex gap-2">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-primary/10 text-primary border border-primary/20">
                          {session.levelTag}
                        </span>
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-accent/10 text-accent border border-accent/20">
                          {session.badge}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Faculty Info */}
                  <div className="flex items-center gap-3">
                    <ImageWithFallback
                      src={session.faculty.image}
                      alt={session.faculty.name}
                      className="w-10 h-10 rounded-full object-cover border-2 border-white shadow-sm"
                    />
                    <div>
                      <p className="text-xs text-muted-foreground">Faculty</p>
                      <p className="text-sm text-foreground">{session.faculty.name}</p>
                    </div>
                  </div>
                </div>

                {/* Details */}
                <div className="p-4 space-y-3">
                  <div className="flex items-start gap-3">
                    <Calendar className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-muted-foreground mb-0.5">Batch Starts</p>
                      <p className="text-sm text-foreground">{session.batchStart}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-muted-foreground mb-0.5">Class Timings</p>
                      <p className="text-sm text-foreground">{session.timing}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Video className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-muted-foreground mb-0.5">Mode</p>
                      <p className="text-sm text-accent">{session.mode}</p>
                    </div>
                  </div>

                  {/* Stats Row */}
                  <div className="flex items-center justify-between pt-3 border-t border-border">
                    <div className="flex items-center gap-2">
                      <Users className="w-3.5 h-3.5 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground">{session.students} enrolled</span>
                    </div>
                    <span className="text-xs text-accent">{session.seats}</span>
                  </div>
                </div>

                {/* CTA Footer */}
                <div className="p-4 bg-muted/20 border-t border-border">
                  <Button className="w-full bg-primary hover:bg-primary/90 text-white">
                    View Batch Details
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl lg:text-3xl mb-3 text-foreground">
            Can't Find Your Preferred Timing?
          </h2>
          <p className="text-base text-muted-foreground mb-6">
            We offer flexible batch schedules. Talk to our counselor to find the perfect batch for you.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-white">
              Request Custom Schedule
            </Button>
            <Button size="lg" variant="outline">
              Talk to Counselor
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
