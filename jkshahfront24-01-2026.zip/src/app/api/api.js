const BASE_URL = import.meta.env.VITE_API_URL;

export const authApi = {
    async login(credentials) {
        const response = await fetch(`${BASE_URL}/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(credentials),
        });
        return { ok: response.ok, status: response.status, data: await response.json() };
    },

    async register(userData) {
        const response = await fetch(`${BASE_URL}/auth/register`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(userData),
        });
        return { ok: response.ok, status: response.status, data: await response.json() };
    },

    async forgotPassword(email) {
        const response = await fetch(`${BASE_URL}/auth/forgotpassword`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email }),
        });
        return { ok: response.ok, status: response.status, data: await response.json() };
    },

    async resetPassword(token, password) {
        const response = await fetch(`${BASE_URL}/auth/resetpassword/${token}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ password }),
        });
        return { ok: response.ok, status: response.status, data: await response.json() };
    }
};

export const categoryApi = {
    async getCategories() {
        const response = await fetch(`${BASE_URL}/categories`);
        return { ok: response.ok, data: await response.json() };
    },

    async addCategory(name, description, parent, slug, metaTitle, metaDescription, metaKeywords) {
        const response = await fetch(`${BASE_URL}/categories`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, description, parent, slug, metaTitle, metaDescription, metaKeywords }),
        });
        return { ok: response.ok, data: await response.json() };
    },

    async updateCategory(id, categoryData) {
        const response = await fetch(`${BASE_URL}/categories/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(categoryData),
        });
        return { ok: response.ok, data: await response.json() };
    },

    async deleteCategory(id) {
        const response = await fetch(`${BASE_URL}/categories/${id}`, {
            method: "DELETE",
        });
        return { ok: response.ok, data: await response.json() };
    }
};

export const levelApi = {
    async getLevels() {
        const response = await fetch(`${BASE_URL}/levels`);
        return { ok: response.ok, data: await response.json() };
    },

    async addLevel(name, description) {
        const response = await fetch(`${BASE_URL}/levels`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, description }),
        });
        return { ok: response.ok, data: await response.json() };
    },

    async deleteLevel(id) {
        const response = await fetch(`${BASE_URL}/levels/${id}`, {
            method: "DELETE",
        });
        return { ok: response.ok, data: await response.json() };
    }
};

export const landingPageApi = {
    async getLandingContent() {
        const response = await fetch(`${BASE_URL}/content/landing`);
        return { ok: response.ok, data: await response.json() };
    },

    async updateLandingContent(contentData) {
        const response = await fetch(`${BASE_URL}/content/landing`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(contentData),
        });
        return { ok: response.ok, data: await response.json() };
    }
};


export const courseApi = {
    async getCourses() {
        const response = await fetch(`${BASE_URL}/courses`);
        return { ok: response.ok, data: await response.json() };
    },

    async getCourse(id) {
        const response = await fetch(`${BASE_URL}/courses/${id}`);
        return { ok: response.ok, data: await response.json() };
    },

    async addCourse(courseData) {
        const response = await fetch(`${BASE_URL}/courses`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(courseData),
        });
        return { ok: response.ok, data: await response.json() };
    },

    async updateCourse(id, courseData) {
        const response = await fetch(`${BASE_URL}/courses/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(courseData),
        });
        return { ok: response.ok, data: await response.json() };
    },

    async deleteCourse(id) {
        const response = await fetch(`${BASE_URL}/courses/${id}`, {
            method: "DELETE",
        });
        return { ok: response.ok, data: await response.json() };
    }
};

export const facultyApi = {
    async getFaculties() {
        const response = await fetch(`${BASE_URL}/faculties`);
        return { ok: response.ok, data: await response.json() };
    },

    async addFaculty(facultyData) {
        const response = await fetch(`${BASE_URL}/faculties`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(facultyData),
        });
        return { ok: response.ok, data: await response.json() };
    },

    async updateFaculty(id, facultyData) {
        const response = await fetch(`${BASE_URL}/faculties/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(facultyData),
        });
        return { ok: response.ok, data: await response.json() };
    },

    async deleteFaculty(id) {
        const response = await fetch(`${BASE_URL}/faculties/${id}`, {
            method: "DELETE",
        });
        return { ok: response.ok, data: await response.json() };
    }
};

export const userApi = {
    async getUsers() {
        const response = await fetch(`${BASE_URL}/users`);
        return { ok: response.ok, data: await response.json() };
    },

    async updateUser(id, userData) {
        const response = await fetch(`${BASE_URL}/users/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(userData),
        });
        return { ok: response.ok, data: await response.json() };
    }
};

export const batchApi = {
    async getBatches() {
        const response = await fetch(`${BASE_URL}/batches`);
        return { ok: response.ok, data: await response.json() };
    },

    async addBatch(batchData) {
        const response = await fetch(`${BASE_URL}/batches`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(batchData),
        });
        return { ok: response.ok, data: await response.json() };
    },

    async deleteBatch(id) {
        const response = await fetch(`${BASE_URL}/batches/${id}`, {
            method: "DELETE",
        });
        return { ok: response.ok, data: await response.json() };
    }
};

export const dashboardApi = {
    async getStats() {
        const response = await fetch(`${BASE_URL}/dashboard/stats`);
        return { ok: response.ok, data: await response.json() };
    }
};
